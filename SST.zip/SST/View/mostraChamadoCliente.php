<?php
include("../Model/model_MostraChamado.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metatags Obrigatórias -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'>

    <!-- CSS -->
    <link href="../Assets/css/mostraChamadoBegins.css" rel="stylesheet">
    <link href="../Assets/css/cardAnimado.css" rel="stylesheet">
    <link href="../Assets/css/font.css" rel="stylesheet">
    <title>Suporte Técnico TCB</title>
    <link rel="icon" href="../Assets/img/icone.png">

</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-light bg-light" role="navigation">
        <a class="navbar-brand" href="index.php">
            <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65" style="margin-left: 30px;">
        </a>
        <div class="navbar-header">
            <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%" style="margin-left: -30px;" class="d-inline-block align-text-center">
        </div>

        <div class="collapse navbar-collapse">
        </div>
    </nav>
    <!-- fim navbar -->

    <!-- Cards-->
    <div class="countainer countainer-cadastro">
        <div class="row">
            <div class="col-1 col-sm col-md col-lg-1">
                <!-- BOTÃO VOLTAR -->
                
                <a href='index.php'>
                    <button type="button" class="btn btn-transparent">
                        <i class="fa fa-arrow-circle-left" aria-hidden="true"></i>
                    </button>
                </a>
            </div>
            <div class="col-1 col-sm col-md col-lg-1">
            </div>
            <div class="col-1 col-sm col-md col-lg-1">
            </div>
            <div class="col-6 col-sm col-md col-lg-6">
                <span class="span-title-page">Meus Chamados</span>
            </div>
            <div class="col-1 col-sm col-md col-lg-1">
            </div>
            <div class="col-1 col-sm col-md col-lg-1">
            </div>
            <div class="col-1 col-sm col-md col-lg-1">
                <!-- BOTÃO HOME -->
                <a href='index.php'>
                <button type="button" value="submit" class="btn btn-transparent">
                    <i class="fa fa-home" aria-hidden="true"></i>
                </button>
                </a>
            </div>
            <div class="linha-deco mb-5">
            </div>
        </div>
        <div class="row">
            <?php
            while ($registro = mysqli_fetch_array($resultado_chamado)) {
                //armazena a cada loop um registro do banco nas variáveis e as mostra na tela com o echo
                $id_chamado = $registro['idChamado'];
                $problema = $registro['Fk_Problema'];
                $departamento = $registro['Fk_Departamento'];
                $pessoa = $registro['Pessoa'];
                $tecnico = $registro['Fk_Tecnico'];
                $adm = $registro['Administrador'];
                $data = $registro['Data_chamado'];


                //Puxa o nome da pessoa na qual tem aquele tipo de matrícula
                $pessoa = "'" . $pessoa . "'";
                $sql_nome = "SELECT Nome FROM pessoa WHERE Matrícula = $pessoa";
                $result_nome = mysqli_query($conexao, $sql_nome) or die("Erro ao puxar nome do colaborador");

                //Puxa o pela tabela técnico o status do chamado
                $sql_status = "SELECT `status` FROM tecnico WHERE idTecnico = $tecnico";
                $result_status = mysqli_query($conexao, $sql_status) or die("Erro ao puxar status");

                //O mesmo ocorre para o problema onde puxamos a descricao do problema através do Fk_Problema que é o id de problema
                $sql_problema = "SELECT Problema FROM problema WHERE idProblema = $problema";
                $result_problema = mysqli_query($conexao, $sql_problema) or die("Erro ao puxar informação do problema");

                //variavel do nome do colaborador
                $var_nome = mysqli_fetch_array($result_nome);
                $nome = $var_nome['Nome'];

                //variavel para puxar o status
                $var_status =  mysqli_fetch_array($result_status);
                $status = $var_status['status'];

                $var_problema =  mysqli_fetch_array($result_problema);
                $vr_problema = $var_problema['Problema'];

            ?>
                <div class="col-12 col-sm-6 col-md-6 col-lg-4 margin-card">
                    <form method="POST" action="../Controller/controller_mostraCompleto.php">
                        <input type="hidden" name="id" value="<?= $id_chamado ?>" />
                        <button type="submit" class="btn main-btn cardChamado">
                            <p>
                                <?php
                                echo "Número do Chamado: ";
                                echo $id_chamado;
                                echo "<br>";
                                echo $nome;
                                echo "<br>";
                                echo "problema: ";
                                if ($vr_problema == 1) {
                                    echo "Internet";
                                }
                                if ($vr_problema == 2) {
                                    echo "Telefone";
                                }
                                if ($vr_problema == 3) {
                                    echo "Computador";
                                }
                                if ($vr_problema == 4) {
                                    echo "Impressora";
                                }
                                if ($vr_problema == 5) {
                                    echo "SEI";
                                }
                                if ($vr_problema == 6) {
                                    echo "Outro";
                                }
                                echo "<br>";
                                echo "Status: ";
                                if ($status == 1) {
                                    echo "Aguardando Tecnico";
                                }
                                if ($status == 2) {
                                    echo "Em andamento";
                                }
                                if ($status == 3) {
                                    echo "Encerrado";
                                }
                                echo "<br>";
                                echo "Data de abertura";
                                echo "<br>";
                                echo $data;
                                echo "<br>";
                                ?>
                            </p>
                        </button>
                    </form>
                </div>
            <?php } ?>
        </div>
    </div>
    <!-- Scrips JS Boostrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>