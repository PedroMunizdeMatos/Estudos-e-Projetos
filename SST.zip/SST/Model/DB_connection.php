<?php

$host = "localhost";
$usuario = "root";
$senha = "Tcb@12345";
$db = "SST";

$conexao = mysqli_connect($host,$usuario,$senha,$db) or die('Não foi possivel conectar ao Banco de Dados');

?>
