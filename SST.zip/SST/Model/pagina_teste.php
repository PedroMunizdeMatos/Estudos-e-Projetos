<?php

    $usuario = $_COOKIE['usuario'];
    $senha = $_COOKIE['senha'];

    echo $usuario;
    echo "<br>";
    echo $senha;

?>