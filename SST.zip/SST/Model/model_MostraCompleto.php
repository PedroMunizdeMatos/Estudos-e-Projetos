<?php

include_once("DB_connection.php");

        $id = $_COOKIE['id'];

        $sql_code = "SELECT * FROM chamado WHERE idChamado = $id"; 
        $resultado_chamado_completo = mysqli_query($conexao,$sql_code) or die("Erro código (model_MostraCompleto)");

        while($registro = mysqli_fetch_array($resultado_chamado_completo))
    {
        $id_chamado = $registro['idChamado'];
        $problema = $registro['Fk_Problema'];
        $departamento = $registro['Fk_Departamento'];
        $pessoa = $registro['Pessoa'];
        $tecnico = $registro['Fk_Tecnico'];
        $adm = $registro['Administrador'];
        $data = $registro['Data_chamado'];

        //Puxa o nome da pessoa na qual tem aquele tipo de matrícula
        $pessoa = "'".$pessoa."'";
        $sql_nome = "SELECT Nome FROM pessoa WHERE Matrícula = $pessoa"; 
        $result_nome = mysqli_query($conexao,$sql_nome) or die("Erro ao puxar nome do colaborador");

                //variavel do nome do colaborador
                $var_nome = mysqli_fetch_array($result_nome);
                $nome = $var_nome['Nome'];

        
        //Departamento
        $sql_departamento = "SELECT nome_departamento FROM departamento WHERE idDepartamento = $departamento"; 
        $result_departamento = mysqli_query($conexao,$sql_departamento) or die("Erro ao puxar status");

                $var_depto = mysqli_fetch_array($result_departamento);
                $depto = $var_depto['nome_departamento'];


        //Problema
        $sql_problema = "SELECT Problema FROM problema WHERE idProblema = $problema"; 
        $result_problema = mysqli_query($conexao,$sql_problema) or die("Erro ao puxar informação do problema");

                $var_problema =  mysqli_fetch_array($result_problema);
                $vr_problema = $var_problema['Problema'];

        //descricao do problema        
        $sql_problema2 = "SELECT Descricao FROM problema WHERE idProblema = $problema"; 
        $result_problema2 = mysqli_query($conexao,$sql_problema2) or die("Erro ao puxar descricao do problema");

                $var_problema2 =  mysqli_fetch_array($result_problema2);
                $vr_problema2 = $var_problema2['Descricao'];

                if($vr_problema2 == null){
                        $vr_problema2 = "Sem relato";
                      }else{
                        $vr_problema2 = $var_problema2['Descricao'];
                      }

        //status do chamado
        $sql_status = "SELECT `status` FROM tecnico WHERE idTecnico = $tecnico"; 
        $result_status = mysqli_query($conexao,$sql_status) or die("Erro ao puxar status");

                //variavel para puxar o status
                $var_status =  mysqli_fetch_array($result_status);
                $status = $var_status['status'];

        
        //observação do tecnico
        $sql_status2 = "SELECT observacao FROM tecnico WHERE idTecnico = $tecnico"; 
        $result_status2 = mysqli_query($conexao,$sql_status2) or die("Erro ao puxar status");

                //variavel para puxar o status
                $var_status2 =  mysqli_fetch_array($result_status2);
                $status2 = $var_status2['observacao'];

        //nome administrador
        $adm = "'".$adm."'";
        $sql_adm = "SELECT nome FROM administrador WHERE matricula = $adm"; 
        $result_adm = mysqli_query($conexao,$sql_adm) or die("Erro ao puxar nome do administrador, contatar suporte");

                //variavel para puxar o adm
                $var_adm =  mysqli_fetch_array($result_adm);
                
                if($var_adm == null){
                        $adm2 = "Aguarde o atendimento";
                      }else{
                        if($var_adm['nome'] == 'Administrator'){
                                $adm2 = "Aguardando Técnico";
                              }else{

                                $adm2 = $var_adm['nome'];
                 }
                }

                
              
        

    }
    
?>