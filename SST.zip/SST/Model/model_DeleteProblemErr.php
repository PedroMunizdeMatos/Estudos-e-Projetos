<?php
    
    include_once("DB_connection.php");

    //caso dê erro para inserir no chamado, a última coisa adicionada em problema também é deletada
    $sql_code_problema = "SELECT idProblema FROM problema ORDER BY idProblema DESC LIMIT 1";
    $result_problema = mysqli_query($conexao, $sql_code_problema);

    while($registro = mysqli_fetch_array($result_problema))
    {
        $problema_id = $registro['idProblema'];
     }

     $sql_code = "DELETE FROM problema WHERE idProblema = $problema_id";
     $result = mysqli_query($conexao, $sql_code) or die("Erro cod 04");

     echo "<script>
     location.href='../View/cadastro.php';
    </script>";

    ?>
