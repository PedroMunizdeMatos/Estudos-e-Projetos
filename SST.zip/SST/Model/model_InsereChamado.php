<?php
include_once ("DB_connection.php");

$matricula = $_COOKIE['matr_percent'];
$departamento = $_COOKIE['departamento'];
$id_problema = $_COOKIE["id_problema"];
$id_tecnico = $_COOKIE["id_tecnico_cadastro"];
$id_tecnico = $id_tecnico + 1;


//inserindo na tabela chamado
$sql_code = "INSERT INTO chamado (idChamado, Fk_Problema ,Fk_Departamento, Pessoa, Administrador, FK_Tecnico)
    VALUES (null, $id_problema, $departamento, $matricula, 1111, $id_tecnico);";
$result_insert_chamado = mysqli_query($conexao, $sql_code);

if (!$result_insert_chamado)
{
    echo "<script>
    alert('Erro ao cadastrar dados, código (model_InsereChamado)');
    location.href='../model/model_DeleteProblemErr.php';
    </script>";
}

$valor = isset($_COOKIE['user_logado']) ? 'S' : 'N';

if($valor == 'S'){
    echo "<script>
    alert('Cadastrado com Sucesso');
    location.href='../Administrador/View/cadastro.php';
    </script>";
}
else
{
    echo "<script>
        alert('Cadastrado com Sucesso');
        location.href='../View/cadastro.php';
        </script>";
}

mysqli_close($conexao);


?>
