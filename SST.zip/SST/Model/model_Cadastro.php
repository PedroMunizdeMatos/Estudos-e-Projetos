<?php
include_once ("DB_connection.php");

session_start();

$nome = $_COOKIE['nome'];
$matricula = $_COOKIE['matr_percent'];
$matricula2 = $_COOKIE['matricula2'];


//checando se a matrícula e nome conferem
$sql_code = "SELECT * FROM pessoa WHERE matrícula = $matricula && Nome LIKE $nome";
$resultado = mysqli_query($conexao, $sql_code) or die("<script>
    alert('Matrícula ou nome iválidos');
    location.href='../View/cadastro.php';
   </script>");
$result = mysqli_num_rows($resultado);



if ($result < 1)
{

    //checando se a matrícula e nome conferem
    $sql_codee = "SELECT * FROM pessoa WHERE matrícula = $matricula2 && Nome LIKE $nome";
    $resultadoo = mysqli_query($conexao, $sql_codee) or die("<script>
    alert('Matrícula ou nome iválidos');
    location.href='../View/cadastro.php';
   </script>");
    $resulto = mysqli_num_rows($resultadoo);

    if ($resulto < 1)
    {

        echo "
	        <script>
	         alert('Matrícula ou nome iválidos');
	         location.href='../View/cadastro.php';
	        </script>";
        die();

    }
    else
    {
        setcookie('matr_percent', $matricula2, time() + 120, '/');
    }

}



//Cadastrando o problema e descricao em Problema
$problema = $_COOKIE['problema'];
$descricao = $_COOKIE['outros'];

$descricao = "'" . $descricao . "'";

$sql_insert_problema = "INSERT INTO problema (idProblema, Problema, Descricao) VALUES (NULL,$problema,$descricao)";
$resultado_problema = mysqli_query($conexao, $sql_insert_problema) or die("<script>
    alert('Erro ao cadastrar dados, cod 1');
    location.href='../View/cadastro.php';
    </script>");

//cadastrando um novo tecnico - status e observacao do tecnico
$sql_code_tecnico = "SELECT idTecnico FROM tecnico ORDER BY idTecnico DESC LIMIT 1";
$result_tecnico = mysqli_query($conexao, $sql_code_tecnico);

while ($registro_tecnico = mysqli_fetch_array($result_tecnico))
{
    $tecnico_id = $registro_tecnico['idTecnico'];
}
setcookie('id_tecnico_cadastro', $tecnico_id, time() + 120, '/');
$deleta_tecnico = $tecnico_id;

$sql_code_tecnico2 = "INSERT INTO tecnico (idTecnico,`status`,observacao) VALUES (NULL, 1, 'Daqui a poucos minutos um ténico irá te atender')";
$result_tecnico2 = mysqli_query($conexao, $sql_code_tecnico2) or die("Erro model_cadastro err tecnico");


//checando quantos IDs existem na tabela
$sql_code_problema = "SELECT idProblema FROM problema ORDER BY idProblema DESC LIMIT 1";
$result_problema = mysqli_query($conexao, $sql_code_problema);

while ($registro = mysqli_fetch_array($result_problema))
{
    $problema_id = $registro['idProblema'];
}

setcookie('id_problema', $problema_id, time() + 120, '/');
$deleta_problema = $problema_id;

//Cadastrando o Ramal em Pessoa
$ramal = $_COOKIE['ramal'];
$matr = $_COOKIE['matr_percent'];
$var = 0;

$sql_code_pessoa = "SELECT * FROM pessoa WHERE Matrícula = $matr";
$resultado_sql_pessoa = mysqli_query($conexao, $sql_code_pessoa) or die("Erro de checagem (model_Cadastro) 03 ");
$res = mysqli_num_rows($resultado_sql_pessoa);

if($res > 0){

    $sql_update_pessoa = "UPDATE pessoa SET Ramal = $ramal WHERE Matrícula = $matr";
    $resultado_pessoa = mysqli_query($conexao, $sql_update_pessoa) or die("Erro de checagem (model_Cadastro) 04 ");
    $var = 1;
    
    

}else{

    $sql_code_pessoaa = "SELECT * FROM pessoa WHERE $matricula2";
    $resultado_sql_pessoaa = mysqli_query($conexao, $sql_code_pessoaa) or die("Erro de checagem (model_Cadastro) 03.1 ");
    $ress = mysqli_num_rows($resultado_sql_pessoaa);

        if($ress > 0){
            $sql_update_pessoaa = "UPDATE pessoa SET Ramal = $ramal WHERE Matrícula = $matricula2";
            $resultado_pessoaa = mysqli_query($conexao, $sql_update_pessoaa) or die("Erro de checagem (model_Cadastro) 04 ");
        $var = 1;
        }

}

if ($var == 0)
{

    $sql_deleta_problema = "DELETE FROM problema WHERE idProblema = $deleta_problema";
    $resultado_deleta_problema = mysqli_query($conexao, $sql_deleta_problema) or die("<script>
        alert('Erro ao deletar do banco de dados, Contate o Suporte');
        location.href='../View/cadastro.php';
        </script>");

    echo "<script>
        alert('Erro ao cadastrar dados, cod 4');
        location.href='../View/cadastro.php';
        </script>";
}

$sql_code_pessoaa = "SELECT * FROM pessoa WHERE $matricula2";
$resultado_sql_pessoaa = mysqli_query($conexao, $sql_code_pessoaa) or die("Erro de checagem (model_Cadastro) 03 ");
$ress = mysqli_num_rows($resultado_sql_pessoaa);



$valor = isset($_COOKIE['user_logado']) ? 'S' : 'N';

if ($valor == 'S')
{
    echo "<script>
    alert('Cadastrado com Sucesso');
    location.href='../Administrador/View/cadastro.php';
    </script>";
}
else
{
    echo "<script>
        alert('Cadastrado com Sucesso');
        location.href='../View/cadastro.php';
        </script>";
}

header("Location: ../Model/model_InsereChamado.php");

mysqli_close($conexao);

?>
