<?php

include_once("DB_connection.php");

        $matricula_cliente = $_COOKIE['matricula'];
        $sql_code = "SELECT * FROM chamado WHERE Pessoa = $matricula_cliente order by idChamado DESC"; 
        $resultado_chamado = mysqli_query($conexao,$sql_code) or die("Erro código (model_MostraChamado)");
        
?>