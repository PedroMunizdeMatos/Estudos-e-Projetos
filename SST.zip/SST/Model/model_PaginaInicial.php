<?php
include_once ("DB_connection.php");

session_start();

//$matricula_cliente = $_SESSION['matricula'];
$matricula_cliente = $_COOKIE['matricula'];
$matricula2 = $_COOKIE['matricula2'];

$sql_code = "SELECT * FROM pessoa WHERE matrícula = $matricula_cliente";
$resultado = mysqli_query($conexao, $sql_code) or die("Erro código (model_Paginainicial) 01 ");

$variavel = mysqli_num_rows($resultado);

if ($variavel > 0)
{
    $sql_code = "SELECT * FROM chamado WHERE Pessoa = $matricula_cliente";
    $resultado_chamado = mysqli_query($conexao, $sql_code) or die("Erro código (model_Paginainicial) 02 ");

}
else
{

    $sql_code = "SELECT * FROM pessoa WHERE matrícula = $matricula2";
    $resultado = mysqli_query($conexao, $sql_code) or die("Erro código (model_Paginainicial) 011 ");

    $variavel = mysqli_num_rows($resultado);

    if ($variavel > 0)
    {
        $sql_code = "SELECT * FROM chamado WHERE Pessoa = $matricula2";
        $resultado_chamado = mysqli_query($conexao, $sql_code) or die("Erro código (model_Paginainicial) 022 ");
        setcookie('matricula', $matricula2, time()+3600, '/');
    }

    else
    {
        echo "
	        <script>
	         alert('Matrícula não cadastrada no Banco de Dados, contatar a UTINF');
	         location.href='../View/index.php';
	        </script>";
        die();
    }
}

if (mysqli_num_rows($resultado_chamado) == 0)
{
    echo "
	        <script>
	         alert('Matrícula sem chamados abertos');
	         location.href='../View/index.php';
	        </script>";
    die();
}

if (mysqli_num_rows($resultado_chamado) > 0)
{
    header("Location: ../View/mostraChamadoCliente.php");
}

mysqli_close($conexao);

?>
