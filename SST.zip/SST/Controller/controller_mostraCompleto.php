<?php

$id = $_POST["id"];

setcookie('id', $id, time()+3600, '/');
 
echo "<script>
location.href='../View/mostraChamadoCompleto.php';
</script>";
    
?>