<?php

session_start();

    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];
    $departamento = $_POST["departamento"];
    $ramal = $_POST["ramal"];
    $problema = $_POST["problema"];
    $outros = $_POST["outros"];
    
    $achavazio = " ";
    $substituiporpercent = "%";
    $nomecompercent = $nome;
    $nomecompercent = str_replace($achavazio, $substituiporpercent, $nomecompercent);
    $nomecompercent = "'".$nomecompercent."'";
    
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;
    $matricula2 = $comzeros;

    $matriculacompercent = "'".$matricula."'";
    $matriculacompercent2 = "'".$matricula2."'";

    if($outros == NULL){
        $outros = 'Sem relato';
    }

    //tem o cookie id problema
    setcookie('nome', $nomecompercent, time()+120, '/');
    setcookie('matricula', $matricula , time()+120, '/');
    setcookie('matricula2', $matriculacompercent2, time()+120, '/');
    setcookie('departamento', $departamento, time()+120, '/');
    setcookie('ramal', $ramal, time()+120, '/');
    setcookie('problema', $problema, time()+120, '/');
    setcookie('outros', $outros, time()+120, '/');
    setcookie('matr_percent', $matriculacompercent, time()+120, '/');

    /*$_SESSION['nome'] = $nomecompercent;
    $_SESSION['matricula'] = $matricula;
    $_SESSION['departamento'] = $departamento;
    $_SESSION['ramal'] = $ramal;
    $_SESSION['problema'] = $problema;
    $_SESSION['outros'] = $outros;
    $_SESSION['matr_percent'] = $matriculacompercent;
    */
    
    header("Location: ../Model/model_Cadastro.php");
    exit();
            
?>