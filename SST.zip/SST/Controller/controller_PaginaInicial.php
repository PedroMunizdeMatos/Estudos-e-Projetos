<?php

session_start();

    setcookie('matricula', null, -1, '/'); 

    $matricula = $_POST["matricula"];
    $matricula2 = $matricula;

    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;
    
    $matricula = "'".$matricula."'";
    $matricula2 = "'".$matricula2."'";

    //$_SESSION['matricula'] = $matricula;

    setcookie('matricula', $matricula, time()+3600, '/');
    setcookie('matricula2', $matricula2, time()+3600, '/');
 

    header("Location: ../Model/model_PaginaInicial.php");
    exit();
            
?>