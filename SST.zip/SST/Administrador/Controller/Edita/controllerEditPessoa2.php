<?php

session_start();
    //criar uma session com idMatricula clicada para ficar na espera para ser usada de parâmetro para saber qual matrícula é a q o adm se refere
    $idMatricula = $_POST['idMatricula'];
    $idMatricula = "'".$idMatricula."'";

    setcookie('idMatricula', $idMatricula, time() + 3600, '/');

    header("Location: ../../Model/Edita/model_EditPessoa2.php");
    exit();

?>