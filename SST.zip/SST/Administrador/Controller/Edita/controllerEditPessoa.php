<?php

session_start();

    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];
    $ramal = $_POST["ramal"];

    $nome = "'".$nome."'";
    $matricula = "'".$matricula."'";
    $ramal = "'".$ramal."'";
    
    //tira os zeros da frente da matricula
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;

    setcookie('nome', $nome, time() + 120, '/');
    setcookie('matricula', $matricula, time() + 120, '/');
    setcookie('ramal', $ramal, time() + 120, '/');

    header("Location: ../../Model/Edita/model_EditPessoa.php");
    exit();

?>