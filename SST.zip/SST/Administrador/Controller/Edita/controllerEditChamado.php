<?php
    
    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];
    $departamento = $_POST["departamento"];
    $n_problema = $_POST["problema"];
    $descricao_problema = $_POST["outros"];
    $status = $_POST["status"];
    $observacao_tecnico = $_POST["observacao"];
    $ramal = $_POST["ramal"];
    $matriculadm = $_POST["matriculadm"];

    echo $nome = "'".$nome."'"; echo "<br>";
    echo $matricula = "'".$matricula."'";echo "<br>";
    echo $departamento = "'".$departamento."'";echo "<br>";
    echo $n_problema = "'".$n_problema."'";echo "<br>";
    echo $descricao_problema = "'".$descricao_problema."'";echo "<br>";
    echo $status = "'".$status."'";echo "<br>";
    echo $observacao_tecnico = "'".$observacao_tecnico."'";echo "<br>";
    echo $ramal = "'".$ramal."'";
    echo $matriculadm = "'".$matriculadm."'";
    
    //tira os zeros da frente da matricula
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;

    setcookie('nome', $nome, time() + 3600, '/');
    setcookie('matricula', $matricula, time() + 3600, '/');
    setcookie('departamento', $departamento, time() + 3600, '/');
    setcookie('n_problema', $n_problema, time() + 3600, '/');
    setcookie('descricao_problema', $descricao_problema, time() + 3600, '/');
    setcookie('status', $status, time() + 3600, '/');
    setcookie('observacao_tecnico', $observacao_tecnico, time() + 3600, '/');
    setcookie('ramal', $ramal,  time() + 3600, '/');
    setcookie('admin', $matriculadm,  time() + 3600, '/');
    

   header("Location: ../../Model/Edita/model_EditChamado.php");
exit();

?>