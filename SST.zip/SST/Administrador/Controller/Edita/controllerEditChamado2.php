<?php

session_start();
    //criar uma session com idMatricula clicada para ficar na espera para ser usada de parâmetro para saber qual matrícula é a q o adm se refere
    $idChamado = $_POST['idChamado'];
    $idChamado = "'".$idChamado."'";
    
    setcookie('idChamado', $idChamado, time() + 3600, '/');

    header("Location: ../../Model/Edita/model_EditChamado2.php");
    exit();

?>