<?php

session_start();
    //criar uma session com idMatricula clicada para ficar na espera para ser usada de parâmetro para saber qual matrícula é a q o adm se refere
    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];
    $senha = $_POST["password"];
    $senha2 = $_POST["password2"];
    $nivel = $_POST["nivel"];


    $nome = "'".$nome."'";
    $matricula = "'".$matricula."'";
    $senha = "'".$senha."'";
    $senha2 = "'".$senha2."'";
    

    //tira os zeros da frente da matricula
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;

    $_SESSION['nome'] = $nome;
    $_SESSION['matricula'] = $matricula;
    $_SESSION['senha'] = $senha;
    $_SESSION['nivel'] = $nivel;

    
    if($senha != $senha2){
        echo"
        <script>
         alert('Senhas não conferem, tente novamente');
         location.href='../../View/editAdministrador.php';
        </script>";
    }else{
    header("Location: ../../Model/Edita/model_EditAdministrador.php");
    }
  
    exit();

?>