<?php

session_start();

    $filtro = $_POST["filtro"];
    $informacao = $_POST['informacao'];
    $filtro = "'".$filtro."'";
    $informacao = "'".$informacao."'";
    
    //tira os zeros da frente da matricula
    $comzeros = $informacao;
    $semzeros = ltrim($comzeros, "0");
    $informacao = $semzeros;
   
    setcookie('sinal', $filtro, time() + 3600, '/');
    setcookie('informacao', $informacao, time() + 3600, '/');

    header("Location: ../../View/pessoa.php");
    exit();

?>