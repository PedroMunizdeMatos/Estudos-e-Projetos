<?php

    $sinal = $_POST["sinal"];
    $info = $_POST['info'];
    //caso esse post assim funcione, tirar os "'" dos if

    //$sinal = 4;
    //$info = '2021-09-14';

    if($sinal == 2){
    $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+2, '/');
    setcookie('informacao', $info, time()+2, '/');
    }

    if($sinal == 1){
    $info = substr_replace($info, '%', 100);
    $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+2, '/');
    setcookie('informacao', $info, time()+2, '/');

    }

    if($sinal == 3){
        $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+2, '/');
    setcookie('informacao', $info, time()+2, '/');
    
    }

    if($sinal == 4){
        $info = substr_replace($info, '%', 2);
        $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+2, '/');
    setcookie('informacao', $info, time()+2, '/');

    }

    if($sinal == 5){
        $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+2, '/');
    setcookie('informacao', $info, time()+2, '/');
   
    }


    header("Location: ../../View/ademiro.php");

    exit();

?>