<?php
$original = 'Yago';
$resultado = substr_replace($original, '%', 100);

echo $resultado;
?>