<?php

    $sinal = $_POST["sinal"];
    $info = $_POST['info'];

   /* $sinal = 3;
    $info = '1254';*/

    if($sinal == 1){
    $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+10, '/');
    setcookie('informacao', $info, time()+10, '/');
 
    }

    if($sinal == 2){
    $info = substr_replace($info, '%', 100);
    $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+10, '/');
    setcookie('informacao', $info, time()+10, '/');
   
    }

    if($sinal == 3){
    $info = "'".$info."'";
    setcookie('sinal', $sinal, time()+10, '/');
    setcookie('informacao', $info, time()+10, '/');
    }

   header("Location: ../../View/pessoa.php");

    exit();

?>