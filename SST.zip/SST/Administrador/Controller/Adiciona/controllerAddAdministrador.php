<?php

session_start();

    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];
    $senha = $_POST["password"];
    $senha2 = $_POST["password2"];
    $nivel = $_POST["nivel"];

    if($senha == $senha2){

    $nome = "'".$nome."'";
    $matricula = "'".$matricula."'";
    $senha = "'".$senha."'";
    
    //tira os zeros da frente da matricula
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;

    $_SESSION['nome'] = $nome;
    $_SESSION['matricula'] = $matricula;
    $_SESSION['senha'] = $senha;
    $_SESSION['nivel'] = $nivel;
    
    header("Location: ../../Model/Adiciona/model_AddAdministrador.php");
    exit();

        }else{

    echo "<script>
    alert('Senhas não conferem, tente novamente');
    location.href='../../View/cadastroAdministrador.php';
    </script>";
    session_destroy();

    }
?>