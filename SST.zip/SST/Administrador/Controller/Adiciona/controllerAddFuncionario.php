<?php

session_start();

    $nome = $_POST["nome"];
    $matricula = $_POST["matricula"];

    $nome = strtoupper($nome);
    $nome = "'".$nome."'";
    $matricula = "'".$matricula."'";
    
    //tira os zeros da frente da matricula
    $comzeros = $matricula;
    $semzeros = ltrim($comzeros, "0");
    $matricula = $semzeros;

    setcookie('add_nome_usuario', $nome, time()+60, '/');
    setcookie('add_matricula_usuario', $matricula, time()+60, '/');

    header("Location: ../../Model/Adiciona/model_AddFuncionario.php");
    exit();

?>