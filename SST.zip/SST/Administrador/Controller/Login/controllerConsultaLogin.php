<?php

$valor = isset($_COOKIE['user_logado']) ? 'S' : 'N';

if($valor == 'N') {

	echo "<script>
        alert('Faça o login');
        location.href='../View/login.php';
        </script>";

   exit();
}
