<?php
setcookie('user_logado', null, -1, '/'); 
header('Location: ../../View/login.php');
exit();