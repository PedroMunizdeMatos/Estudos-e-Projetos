<?php

include_once("../../../Model/DB_connection.php");

session_start();
    
    if(empty($_POST['login']) || empty($_POST['password'])) {
        echo"
        <script>
         alert('Login ou Senha inválidos');
         location.href='../../View/login.php';
        </script>";
        die();
    }

    $usuario = mysqli_real_escape_string($conexao, $_POST['login']);
    $senha = mysqli_real_escape_string($conexao, $_POST['password']);

    $usuario = "'".$usuario."'";
    $senha = "'".$senha."'";

    $_SESSION['usuario'] = $usuario;
    $_SESSION['senha'] = $senha;
 
    header("Location: ../../Model/Login/modelLogin.php");

    exit();
            
?>
