<?php

    $matricula = $_POST["matrPessoa"];

    $matricula = "'".$matricula."'";

    setcookie('del_funcionario', $matricula, time() + 60, '/');

    header("Location: ../../Model/Deleta/model_DelFuncionario.php");
    exit();

?>