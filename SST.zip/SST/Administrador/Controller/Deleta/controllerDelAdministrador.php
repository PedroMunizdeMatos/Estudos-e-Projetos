<?php

session_start();

    $matricula = $_POST["matrAdm"];

    $matricula = "'".$matricula."'";

    setcookie('del_Administrador', $matricula, time() + 60, '/');

    header("Location: ../../Model/Deleta/model_DelAdministrador.php");
    exit();

?>