<?php
//controllerEditPessoa
setcookie('nome', null, -1, '/');
setcookie('matricula', null, -1, '/');
setcookie('ramal', null,-1, '/');

//controllerEditPessoa2
setcookie('idMatricula', null, -1, '/');

//modelEditPessoa2
setcookie('nome_pessoa', null, -1, '/');
setcookie('matricula', null, -1, '/');
setcookie('ramal', null, -1, '/');

//controlerEditChamado2
setcookie('idChamado', null, -1, '/');

//controllerEditChamado
setcookie('nome', null, -1, '/');
setcookie('matricula', null, -1, '/');
setcookie('departamento',null, -1, '/');
setcookie('n_problema', null, -1, '/');
setcookie('descricao_problema', null, -1, '/');
setcookie('status', null, -1, '/');
setcookie('observacao_tecnico', null, -1, '/');
setcookie('matr_administrador',null, -1, '/');
setcookie('data', null, -1, '/');

//model_EditChamado2
setcookie('nome_editC2', $nome, time() + 3600, '/');
setcookie('matricula_editC2', $pessoa, time() + 3600, '/');
setcookie('departamento_editC2', $depto, time() + 3600, '/');
setcookie('descricao_problema_editC2', $vr_problema2, time() + 3600, '/');
setcookie('status_editC2', $status, time() + 3600, '/');
setcookie('observacao_tecnico_editC2', $status2, time() + 3600, '/');
setcookie('matr_administrador_editC2', $adm, time() + 3600, '/');
setcookie('data_editC2', $data, time() + 3600, '/');
setcookie('ramal_editC2', $vr_ramal, time() + 3600, '/');
setcookie('n_problema_editC2', "Outro", time() + 3600, '/');

header('Location: ../../View/login.php');
exit();