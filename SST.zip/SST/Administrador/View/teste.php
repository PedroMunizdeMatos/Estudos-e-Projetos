<?php 

$nome = $_POST['sinal'];
$nomee = $_POST['info'];

echo $nome;
echo "<br>";
echo $nomee;


?>