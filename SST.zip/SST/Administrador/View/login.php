
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="../Assets/img/icone.png"/>
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/animate/animate.css">	
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="../Assets/css/util.css">
	<link rel="stylesheet" type="text/css" href="../Assets/css/main.css">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="POST" action="../Controller/Login/controllerLogin.php">
					<span class="login100-form-title p-b-48">
						<a href="../../View/index.php"><img src="../Assets/img/UTINFBLUE.png"></a>
					</span>

					<div class="wrap-input100 validate-input" data-validate ="Login Inválido">
						<input class="input100" type="text" name="login">
						<span class="focus-input100" data-placeholder="Login"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Senha Inválida">
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye"></i>
						</span>
						<input class="input100" type="password" name="password">
						<span class="focus-input100" data-placeholder="Senha"></span>
					</div>
					<a href="../Controller/Login/controllerLogin2.php" style="margin-left: 15%;">Já está logado? Clique Aqui!</a>
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Login
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
	<script src="../Assets/vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="../Assets/vendor/animsition/js/animsition.min.js"></script>
	<script src="../Assets/vendor/bootstrap/js/popper.js"></script>
	<script src="../Assetsvendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="../Assets/vendor/select2/select2.min.js"></script>
	<script src="../Assets/vendor/daterangepicker/moment.min.js"></script>
	<script src="../Assets/vendor/daterangepicker/daterangepicker.js"></script>
	<script src="../Assets/vendor/countdowntime/countdowntime.js"></script>
	<script src="../Assets/js/main.js"></script>

</body>
</html>