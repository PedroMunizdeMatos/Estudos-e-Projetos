<?php
include_once("../Controller/Login/controllerConsultaLogin.php");
include("../Model/Mostra/model_Pessoas.php");
$usuario = $_COOKIE['user_logado'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>SST - Controle de Usuários</title>
  <link rel="icon" href="../Assets/img/icone.png">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'>
  <link rel="stylesheet" href="https://cdn.es.gov.br/fonts/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../Assets/css/style.css">
  <link rel="stylesheet" href="../Assets/css/adm.css">
  <link rel="stylesheet" href="../Assets/css/table.css">
  <link rel="stylesheet" href="../Assets/css/font.css">
  <link rel="stylesheet" href="../Assets/css/navbar.css">
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-light bg-light" role="navigation">
    <a class="navbar-brand" href="../../View/index.php">
      <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65" style="margin-left: 30px;">
    </a>
    <div class="navbar-header">
      <a class="navbar-brand" href="./ademiro.php">
        <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%" style="margin-left: -30px;" class="d-inline-block align-text-center">
      </a>
    </div>
    <div class="collapse navbar-collapse">
    </div>
  </nav>
  <!-- partial:index.partial.html -->
  <div class="page-wrapper chiller-theme">
    <a id="show-sidebar" class="btn btn-sm btn-color" href="#">
      <i class="fas fa-bars"></i>
    </a>
    <nav id="sidebar" class="sidebar-wrapper">
      <div class="sidebar-content">
        <div class="sidebar-brand">
          <a href="#">SST</a>
          <div id="close-sidebar">
            <i class="fas fa-times"></i>
          </div>
        </div>
        <div class="sidebar-header">
          <div class="user-pic">
            <img class="img-responsive img-rounded" src="https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg" alt="User picture">
          </div>
          <div class="user-info">
            <span class="user-name">
              <strong><?php echo $usuario ?></strong>
            </span>
            <span class="user-role">Administrator </span>
            <span class="user-status">
              <i class="fa fa-circle"></i>
              <span>Online</span>
            </span>
          </div>
        </div>
        <!-- sidebar-header  -->

        <!-- sidebar-search  -->
        <div class="sidebar-menu">
          <ul>
            <li class="header-menu">
              <span>Acesso</span>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-laptop" aria-hidden="true"></i>
                <span>Chamados</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./ademiro.php">Controle de Chamados</a>
                  </li>
                  <li>
                    <a href="./cadastro.php">Criar Chamado</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-users" aria-hidden="true"></i>
                <span>Usuários</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./pessoa.php">Controle de Usuários</a>
                  </li>
                  <li>
                    <a href="./cadastroPessoa.php">Cadastro de Usuário</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                <span>Administradores</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./administrador.php">Controle de Administradores</a>
                  </li>
                  <li>
                    <a href="./cadastroAdministrador.php">Criar um Administrador</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar">
              <a href="../Controller/Login/controllerLogout.php">
                <i class="fa fa-sign-out" aria-hidden="true"></i>
                <span>Logout</span>
              </a>
            </li>

            <!-- sidebar-menu  -->
        </div>
        <!-- sidebar-content  -->
    </nav>
    <!-- sidebar-wrapper  -->
    <main class="page-content">
      <div class="row justify-content-center align-items-center mg-login">
        <div class="col-10">
          <div class="countainer">
            <div class="row">
              <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-tcb">
                  <span class="span-title">Controle de Usuários</span>
                  <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation"> </button>
                    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                      <!-- FORMULÁRIO PARA FILTRO DE BUSCA -->
                      <form method="POST" action="../Controller/Filtros/controller_pessoa_filtro.php">
                        <ul class="navbar-nav" style="padding-right: 20%;">
                        <select class="form-select form-filtro" id="filtro" name="sinal">
                            <option selected disabled value="">Filtrar por:</option>
                            <option value="2">Nome</option>
                            <option value="1">Matrícula</option>
                            <option value="3">Ramal</option>
                        </ul>
                        <ul class="navbar-nav">
                          <li data-title="Buscar">
                            <div class="input-group">
                              <input type="text" class="form-control search-nav form-filtro" name="info" placeholder="Buscar...">
                              <div class="input-group-append">
                                <div class="input-group-text">
                                  <button type="submit" class="btn-transparent">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </form>
                    </div>
                  </div>
                </nav>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <section>
                  <!--table-->
                  <div class="table-scroll" style="box-shadow: 1px 2px 4px 1px rgba(41, 41, 41, 0.5); margin-top:10px">
                    <table>
                      <thead>
                        <tr>
                          <th>Nome</th>
                          <th>Matrícula</th>
                          <th>Ramal</th>
                          <th style="padding-left:4%">Editar</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        while ($registro = mysqli_fetch_array($resultado_chamado)) {
                          $matricula = $registro['Matrícula'];
                          $nome = $registro['Nome'];
                          $ramal = $registro['Ramal'];
                        ?>
                          <tr>
                            <td data-title="Nome"><?php echo $nome; ?></td>
                            <td data-title="Matrícula"><?php echo $matricula; ?></td>
                            <td data-title="Ramal"><?php echo $ramal; ?></td>
                            <!-- td editar -->
                            <form method="POST" action="../Controller/Edita/controllerEditPessoa2.php">
                              <td data-title="Editar" style="padding-left:4.5%">
                                <button type="submit" class="btn-transparent">
                                  <input type="hidden" name="idMatricula" value="<?= $matricula ?>" />
                                  <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                </button>
                              </td>
                            </form>
                            </td>
                          <?php } ?>
                          <!-- fim td editar -->
                          </tr>
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- page-content" -->
  </div>
  <!-- page-wrapper -->
  <!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script>
  <script src="../Assets/js/main.js"></script>
  <script src="../Assets/js/script.js"></script>
  <script src="../Assets/js/table.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>