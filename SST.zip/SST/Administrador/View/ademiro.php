<?php
session_start();
session_destroy();
include_once("../Controller/Login/controllerConsultaLogin.php");
include_once("../Model/Mostra/model_chamadosTotais.php");
header("Refresh:300");
$usuario = $_COOKIE['user_logado'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>SST - <?php echo $usuario ?></title>
  <link rel="icon" href="../Assets/img/icone.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'>
  <link rel="stylesheet" href="https://cdn.es.gov.br/fonts/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../Assets/css/style.css">
  <link rel="stylesheet" href="../Assets/css/adm.css">
  <link rel="stylesheet" href="../Assets/css/table.css">
  <link rel="stylesheet" href="../Assets/css/font.css">
  <link rel="stylesheet" href="../Assets/css/navbar.css">
  <link rel="stylesheet" href="../Assets/css/toggle.css">
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-light bg-light" role="navigation">
    <a class="navbar-brand" href="../../View/index.php">
      <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65" style="margin-left: 30px;">
    </a>
    <div class="navbar-header">
      <a class="navbar-brand" href="./ademiro.php">
        <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%" style="margin-left: -30px;" class="d-inline-block align-text-center">
      </a>
    </div>
    <div class="collapse navbar-collapse">
    </div>
  </nav>
  <!-- partial:index.partial.html -->
  <div class="page-wrapper chiller-theme">
    <a id="show-sidebar" class="btn btn-sm btn-color" href="#">
      <i class="fas fa-bars"></i>
    </a>
    <nav id="sidebar" class="sidebar-wrapper">
      <div class="sidebar-content">
        <div class="sidebar-brand">
          <a href="#">SST</a>
          <div id="close-sidebar">
            <i class="fas fa-times"></i>
          </div>
        </div>
        <div class="sidebar-header">
          <div class="user-pic">
            <img class="img-responsive img-rounded" src="https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg" alt="User picture">
          </div>
          <div class="user-info">
            <span class="user-name">
              <strong><?php echo $usuario ?></strong>
            </span>
            <span class="user-role">Administrator </span>
            <span class="user-status">
              <i class="fa fa-circle"></i>
              <span>Online</span>
            </span>
          </div>
        </div>
        <!-- sidebar-header  -->

        <!-- sidebar-search  -->
        <div class="sidebar-menu">
          <ul>
            <li class="header-menu">
              <span>Acesso</span>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-laptop" aria-hidden="true"></i>
                <span>Chamados</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./ademiro.php">Controle de Chamados</a>
                  </li>
                  <li>
                    <a href="./cadastro.php">Criar Chamado</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-users" aria-hidden="true"></i>
                <span>Usuários</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./pessoa.php">Controle de Usuários</a>
                  </li>
                  <li>
                    <a href="./cadastroPessoa.php">Cadastro de Usuário</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                <span>Administradores</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="./administrador.php">Controle de Administradores</a>
                  </li>
                  <li>
                    <a href="./cadastroAdministrador.php">Criar um Administrador</a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar">
              <a href="../Controller/Login/controllerLogout.php">
                <i class="fa fa-sign-out" aria-hidden="true"></i>
                <span>Logout</span>
              </a>
            </li>

            <!-- sidebar-menu  -->
        </div>
        <!-- sidebar-content  -->
    </nav>
    <!-- sidebar-wrapper  -->
    <main class="page-content">
      <div class="row justify-content-center align-items-center mg-login">
        <div class="col-10">
          <div class="countainer">
            <div class="row">
              <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-tcb">
                  <span class="span-title">Controle de Chamados</span>
                  <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation"> </button>
                    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                      <!-- FORMULÁRIO PARA FILTRO DE BUSCA -->
                      <form method="POST" action="../Controller/Filtros/controller_chamado_filtro.php">
                        <ul class="navbar-nav" style="padding-right: 20%;">
                          <select class="form-select form-filtro" id="filtro" name="sinal">
                            <option selected disabled value="">Filtrar por:</option>
                            <option value="3">ID Chamado</option>
                            <option value="1">Matrícula</option>
                            <option value="2">Departamento</option>
                            <option value="4">Data</option>
                        </ul>
                        <ul class="navbar-nav">
                          <li data-title="Buscar">
                            <div class="input-group">
                              <input type="text" class="form-control search-nav form-filtro" name="info" placeholder="Buscar...">
                              <div class="input-group-append">
                                <div class="input-group-text">
                                  <button type="submit" class="btn-transparent">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </form>
                    </div>
                  </div>
                </nav>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <section>
                  <!--table-->
                  <div class="table-scroll" style="box-shadow: 1px 2px 4px 1px rgba(41, 41, 41, 0.5); margin-top:10px">
                    <table>
                      <thead>
                        <tr>
                          <th>ID Chamado</th>
                          <th>Nome</th>
                          <th>Departamento</th>
                          <th>Problema</th>
                          <th>Status</th>
                          <th>Editar</th>
                          <th>Ver</th>
                        </tr>
                      </thead>
                      <tbody>
                        <!-- php while -->
                        <?php
                        while ($registro = mysqli_fetch_array($resultado_chamado)) {
                          $id_chamado = $registro['idChamado'];
                          $problema = $registro['Fk_Problema'];
                          $departamento = $registro['Fk_Departamento'];
                          $pessoa = $registro['Pessoa'];
                          $tecnico = $registro['Fk_Tecnico'];
                          $adm = $registro['Administrador'];
                          $data = $registro['Data_chamado'];

                          //Puxa o nome da pessoa na qual tem aquele tipo de matrícula
                          $pessoa = "'" . $pessoa . "'";
                          $sql_nome = "SELECT Nome FROM pessoa WHERE Matrícula = $pessoa";
                          $result_nome = mysqli_query($conexao, $sql_nome) or die("Erro ao puxar nome do colaborador");

                          //variavel do nome do colaborador
                          $var_nome = mysqli_fetch_array($result_nome);

                          if ($var_nome == null) {
                            $nome = "Usuário Excluído";
                          } else {
                            $nome = $var_nome['Nome'];
                          }

                          //Departamento
                          $sql_departamento = "SELECT nome_departamento FROM departamento WHERE idDepartamento = $departamento";
                          $result_departamento = mysqli_query($conexao, $sql_departamento) or die("Erro ao puxar status");

                          $var_depto = mysqli_fetch_array($result_departamento);
                          $depto = $var_depto['nome_departamento'];


                          //Problema
                          $sql_problema = "SELECT Problema FROM problema WHERE idProblema = $problema";
                          $result_problema = mysqli_query($conexao, $sql_problema) or die("Erro ao puxar informação do problema");

                          $var_problema =  mysqli_fetch_array($result_problema);
                          $vr_problema = $var_problema['Problema'];

                          //status do chamado
                          $sql_status = "SELECT `status` FROM tecnico WHERE idTecnico = $tecnico";
                          $result_status = mysqli_query($conexao, $sql_status) or die("Erro ao puxar status");

                          //variavel para puxar o status
                          $var_status =  mysqli_fetch_array($result_status);
                          $status = $var_status['status'];
                        ?>

                          <tr>
                            <td><?php echo $id_chamado; ?></td>
                            <td><?php echo $nome; ?></td>
                            <td><?php echo $depto; ?></td>
                            <td><?php if ($vr_problema == 1) {
                                  echo "Internet";
                                }
                                if ($vr_problema == 2) {
                                  echo "Telefone";
                                }
                                if ($vr_problema == 3) {
                                  echo "Computador";
                                }
                                if ($vr_problema == 4) {
                                  echo "Impressora";
                                }
                                if ($vr_problema == 5) {
                                  echo "SEI";
                                }
                                if ($vr_problema == 6) {
                                  echo "Outro";
                                } ?>
                            </td>
                            <td><?php

                                if ($status == 1) {
                                  echo "Aguardando Tecnico";
                                }
                                if ($status == 2) {
                                  echo "Em andamento";
                                }
                                if ($status == 3) {
                                  echo "Encerrado";
                                }

                                ?></td>
                            <!-- td editar -->
                            <form method="POST" action="../Controller/Edita/controllerEditChamado2.php">
                              <input type="hidden" name="idChamado" value="<?= $id_chamado ?>" />
                              <td data-title="Editar">
                                <button type="submit" class="btn-transparent">
                                  <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                </button>
                              </td>
                            </form>

                            <!-- td ver -->
                            <form method="POST" action="../Controller/Mostra/controllerMostraChamado.php">
                              <input type="hidden" name="idChamado" value="<?= $id_chamado ?>" />
                              <td data-title="ver">
                                <button type="submit" class="btn-transparent">
                                  <i class="fa fa-desktop" aria-hidden="true"></i>
                                </button>
                              </td>
                            </form>

                            </td>




                          <?php } ?>
                          <!-- fim td editar -->
                          </tr>
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- page-content" -->
  </div>
  <!-- page-wrapper -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script>
  <script src="../Assets/js/main.js"></script>
  <script src="../Assets/js/script.js"></script>
  <script src="../Assets/js/table.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>