<?php
error_reporting(E_ERROR | E_PARSE);
$nome_pessoa = $_COOKIE['nome_pessoa'];
$matricula = $_COOKIE['matricula'];
$usuario = $_COOKIE['user_logado'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>SST - <?php echo $usuario ?></title>
    <link rel="icon" href="../Assets/img/icone.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'>
    <link rel="stylesheet" href="https://cdn.es.gov.br/fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Assets/css/style.css">
    <link rel="stylesheet" href="../Assets/css/font.css">
    <link rel="stylesheet" href="../Assets/css/cadastrochamado.css">
</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-light bg-light" role="navigation">
        <a class="navbar-brand" href="../../View/index.php">
            <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65" style="margin-left: 30px;">
        </a>
        <div class="navbar-header">
            <a class="navbar-brand" href="./ademiro.php">
                <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%" style="margin-left: -30px;" class="d-inline-block align-text-center">
            </a>
        </div>
        <div class="collapse navbar-collapse">
        </div>
    </nav>
    <!-- partial:index.partial.html -->
    <div class="page-wrapper chiller-theme">
        <a id="show-sidebar" class="btn btn-sm btn-color" href="#">
            <i class="fas fa-bars"></i>
        </a>
        <nav id="sidebar" class="sidebar-wrapper">
            <div class="sidebar-content">
                <div class="sidebar-brand">
                    <a href="#">SST</a>
                    <div id="close-sidebar">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
                <div class="sidebar-header">
                    <div class="user-pic">
                        <img class="img-responsive img-rounded" src="https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg" alt="User picture">
                    </div>
                    <div class="user-info">
                        <span class="user-name">
                            <strong><?php echo $usuario ?></strong>
                        </span>
                        <span class="user-role">Administrator </span>
                        <span class="user-status">
                            <i class="fa fa-circle"></i>
                            <span>Online</span>
                        </span>
                    </div>
                </div>
                <!-- sidebar-header  -->
              
                <!-- sidebar-search  -->
                <div class="sidebar-menu">
                    <ul>
                        <li class="header-menu">
                            <span>Acesso</span>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-laptop" aria-hidden="true"></i>
                                <span>Chamados</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./ademiro.php">Controle de Chamados</a>
                                    </li>
                                    <li>
                                        <a href="./cadastro.php">Criar Chamado</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-users" aria-hidden="true"></i>
                                <span>Usuários</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./pessoa.php">Controle de Usuários</a>
                                    </li>
                                    <li>
                                        <a href="./cadastroPessoa.php">Cadastro de Usuário</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                <span>Administradores</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./administrador.php">Controle de Administradores</a>
                                    </li>
                                    <li>
                                        <a href="./cadastroAdministrador.php">Criar um Administrador</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar">
                            <a href="../Controller/Login/controllerLogout.php">
                                <i class="fa fa-sign-out" aria-hidden="true"></i>
                                <span>Logout</span>
                            </a>
                        </li>
                        <!-- sidebar-menu  -->
                </div>
                <!-- sidebar-content  -->
        </nav>
        <section>
            <div class="row justify-content-center align-items-center mg-login">
                <div class="col-10">
                    <div class="countainer countainer-cadastro">
                        <div class="row">
                            <div class="col-3 col-sm col-md col-lg-4 margin-h1">
                            <a href='pessoa.php'>
                                <button type="button" value="submit" class="btn btn-transparent-2">
                                    <i class="fa fa-arrow-circle-left" aria-hidden="true"></i>
                                </button>
                                </a>
                            </div>
                            <div class="col-6 col-sm col-md col-lg-4 margin-h1">
                                <span class="span-title-page" style="margin-left: 15%;">Editar Usuário</span>
                            </div>
                            <div class="col-2 col-sm col-md col-lg-3 margin-h1">
                            </div>
                            <div class="col-1 col-sm col-md col-lg-1 margin-h1">

                            <a href='ademiro.php'>
                                <button type="button" value="submit" class="btn btn-transparent-2" style="margin-left: 45%;">
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                </button>
                            </a>
                            </div>
                            <div class="linha-deco mb-5">
                            </div>
                        </div>
                        <form method="POST" action="../Controller/Edita/controllerEditPessoa.php" class="row g-3 needs-validation">
                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 ">
                                <label for="nome" class="form-label">
                                    <div class="text-cadastro">Nome</div>
                                </label>
                                <input type="text" name="nome" value="<?php echo $nome_pessoa; ?>" class="form-control form-cad" placeholder="Digite o primeiro e último nome" id="nome" maxlength="100" required>
                            </div>
                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 ">
                                <label for="matricula" class="form-label">
                                    <div class="text-cadastro">Matrícula</div>
                                </label>
                                <div class="input-group has-validation">
                                    <input type="text" name="matricula" value="<?php echo $matricula; ?>" class="form-control form-cad" placeholder="Apenas números" id="matricula" aria-describedby="inputGroupPrepend" required>
                                </div>
                            </div>
                            <div class="col-6 col-sm-6 col-md-6 col-lg-6 ">
                                <label for="ramal" class="form-label">
                                    <div class="text-cadastro">Ramal</div>
                                </label>
                                <div class="input-group has-validation">
                                    <input type="text" name="ramal" class="form-control form-cad" placeholder="Apenas números" id="ramal" aria-describedby="inputGroupPrepend" required>
                                </div>
                            </div>
                            <div class="col-12 mb-md-0 mb-5 mt-5">
                                <div class="row">
                                    <button class="btn btn-cad" type="submit">Salvar Alterações</button>
                                    <!-- BUTTON EXCLUIR (COLOCAR IF/ELSE PARA NÍVEL DE USUÁRIO) -->
                                   
                                    <button type="button" value="Voltar" onClick="history.go(-1)" class="btn btn-cad" type="">Voltar</button>
                                </div>
                            </div>
                        </form>
                        <div class="row">
                            <div class="col-12 mb-md-0 mb-5 mt-2">
                            </div>
                        </div>
                        <form method="POST" action="../Controller/Deleta/controllerDelFuncionario.php">
                        <input type="hidden" name="matrPessoa" value="<?=$matricula?>" />
                            <div class="col-12 mb-5 mt-0">
                                <button type="submit" class="btn btn-transparent-excluir" style="margin-left: -1.5%;">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                    <span class="span-excluir">Excluir Registros</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Scrips JS Boostrap -->
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script>
        <script src="./script.js"></script>
        <script src="../Assets/js/script.js"></script>
        <script src="../Assets/js/table.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</body>

</html>