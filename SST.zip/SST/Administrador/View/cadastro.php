<?php
    
    include_once("../Controller/Login/controllerConsultaLogin.php");
    setcookie('id_problema',null, -1, '/');
    setcookie('nome', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('departamento', null, -1, '/');
    setcookie('ramal', null, -1, '/');
    setcookie('problema', null, -1, '/');
    setcookie('outros', null, -1, '/');
    setcookie('matr_percent', null, -1, '/');

    $usuario = $_COOKIE['user_logado'];
?>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>SST - <?php echo $usuario ?></title>
  <link rel="icon" href="../Assets/img/icone.png">
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'>
  <link rel="stylesheet" href="https://cdn.es.gov.br/fonts/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../Assets/css/style.css">
  <link rel="stylesheet" href="../Assets/css/font.css">
  <link rel="stylesheet" href="../Assets/css/cadastrochamado.css">
</head>
<body>
      <!-- navbar -->
      <nav class="navbar navbar-light bg-light" role="navigation">
        <a class="navbar-brand" href="../../View/index.php">
            <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65"
                style="margin-left: 30px;">
        </a>
        <div class="navbar-header">
          <a class="navbar-brand" href="./ademiro.php">
              <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%"
                  style="margin-left: -30px;" class="d-inline-block align-text-center">
          </a>
        </div>
        <div class="collapse navbar-collapse">
        </div>
    </nav>
<!-- partial:index.partial.html -->
<div class="page-wrapper chiller-theme">
        <a id="show-sidebar" class="btn btn-sm btn-color" href="#">
            <i class="fas fa-bars"></i>
        </a>
        <nav id="sidebar" class="sidebar-wrapper">
            <div class="sidebar-content">
                <div class="sidebar-brand">
                    <a href="#">SST</a>
                    <div id="close-sidebar">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
                <div class="sidebar-header">
                    <div class="user-pic">
                        <img class="img-responsive img-rounded" src="https://raw.githubusercontent.com/azouaoui-med/pro-sidebar-template/gh-pages/src/img/user.jpg" alt="User picture">
                    </div>
                    <div class="user-info">
                        <span class="user-name">
                            <strong><?php echo $usuario ?></strong>
                        </span>
                        <span class="user-role">Administrator </span>
                        <span class="user-status">
                            <i class="fa fa-circle"></i>
                            <span>Online</span>
                        </span>
                    </div>
                </div>
                <!-- sidebar-header  -->
              
                <!-- sidebar-search  -->
                <div class="sidebar-menu">
                    <ul>
                        <li class="header-menu">
                            <span>Acesso</span>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-laptop" aria-hidden="true"></i>
                                <span>Chamados</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./ademiro.php">Controle de Chamados</a>
                                    </li>
                                    <li>
                                        <a href="./cadastro.php">Criar Chamado</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-users" aria-hidden="true"></i>
                                <span>Usuários</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./pessoa.php">Controle de Usuários</a>
                                    </li>
                                    <li>
                                        <a href="./cadastroPessoa.php">Cadastro de Usuário</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                <span>Administradores</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="./administrador.php">Controle de Administradores</a>
                                    </li>
                                    <li>
                                        <a href="./cadastroAdministrador.php">Criar um Administrador</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar">
                            <a href="../Controller/Login/controllerLogout.php">
                                <i class="fa fa-sign-out" aria-hidden="true"></i>
                                <span>Logout</span>
                            </a>
                        </li>


      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
  </nav>
  <section>
    <div class="row justify-content-center align-items-center mg-login">
      <div class="col-10">
        <div class="countainer countainer-cadastro">
          <div class="row">
            <div class="col-3 col-sm col-md col-lg-4 margin-h1">
            <a href='ademiro.php'>
              <button type="button" value="submit" class="btn btn-transparent-2">
                <i class="fa fa-arrow-circle-left" aria-hidden="true"></i>
              </button>
            </a>
            </div>
            <div class="col-6 col-sm col-md col-lg-4 margin-h1">
              <span class="span-title-page" style="margin-left: 10%;">Cadastro de Chamados</span>
            </div>
            <div class="col-2 col-sm col-md col-lg-3 margin-h1">
            </div>
            <div class="col-1 col-sm col-md col-lg-1 margin-h1">
            <a href='ademiro.php'>
              <button type="button" value="submit"  class="btn btn-transparent-2" style="margin-left: 45%;">
                <i class="fa fa-home" aria-hidden="true"></i>
              </button>
              </a>
            </div>
            <div class="linha-deco mb-5">
            </div>
          </div>
          <form method="POST" action="../../Controller/controller_Cadastro.php" class="row g-3 needs-validation">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12">
              <label for="nome" class="form-label">
                <div class="text-cadastro">Nome</div>
              </label>
              <input type="text" name="nome" class="form-control form-cad" placeholder="Digite o primeiro e último nome..." id="nome" maxlength="100" required>
            </div>
            <div class="col-12 col-sm-3 col-md-3 col-lg-3">
              <label for="matricula" class="form-label">
                <div class="text-cadastro">Matrícula</div>
              </label>
              <div class="input-group has-validation">
                <input type="text" name="matricula" class="form-control form-cad" placeholder="Apenas números" id="matricula" aria-describedby="inputGroupPrepend" minlength="4" maxlength="8" onkeypress="if(this.value.length>=9) { return false;}" oninput="if(this.value.length>=9) { this.value = this.value.slice(8,9); }" required>
              </div>
            </div>
            <div class="col-12 col-sm-3 col-md-3 col-lg-3">
              <label for="departamento" class="form-label">
                <div class="text-cadastro">Departamento</div>
              </label>
              <select class="form-select form-cad" id="departamento" name="departamento" required>
                <option selected disabled value="">Escolha...</option>
                <option value="37">Aeroporto</option>
                <option value="7">ASJUR</option>
                <option value="2">CA</option>
                <option value="1">CF</option>
                <option value="26">DAF</option>
                <option value="3">DC</option>
                <option value="19">DT</option>
                <option value="5">GAB</option>
                <option value="32">GEAPE</option>
                <option value="27">GEFIN</option>
                <option value="20">GEMAN</option>
                <option value="23">GEOPE</option>
                <option value="13">GEPLA</option>
                <option value="16">GEPRO</option>
                <option value="30">NUCAR</option>
                <option value="6">OUVIDORIA</option>
                <option value="4">PRESIDÊNCIA</option>
                <option value="15">SEAP</option>
                <option value="14">SECEP</option>
                <option value="28">SECON</option>
                <option value="25">SECOP</option>
                <option value="31">SECRO</option>
                <option value="18">SEES</option>
                <option value="33">SEGEP</option>
                <option value="35">SEGER</option>
                <option value="21">SEMAN</option>
                <option value="22">SEOFI</option>
                <option value="24">SEOPE</option>
                <option value="36">SEPAT</option>
                <option value="17">SEPLAS</option>
                <option value="38">SEREC</option>
                <option value="29">SETES</option>
                <option value="12">SUPPE</option>
                <option value="10">UCGR</option>
                <option value="9">ULC</option>
                <option value="8">UNAI</option>
                <option value="11">UTINF</option>
              </select>
            </div>
            <div class="col-12 col-sm-3 col-md-3 col-lg-3">
              <label for="ramal" class="form-label">
                <div class="text-cadastro">Ramal</div>
              </label>
              <input type="number" name="ramal" class="form-control form-cad" placeholder="Ex: 1000" id="ramal" aria-describedby="inputGroupPrepend" min="1000" max="9999" onkeypress="if(this.value.length>=5) { return false;}" oninput="if(this.value.length>=5) { this.value = this.value.slice(5,1); }" required>
            </div>
            <div class="col-12 col-sm-3 col-md-3 col-lg-3">
              <label for="problema" class="form-label">
                <div class="text-cadastro">Problema</div>
              </label>
              <select class="form-select form-cad" id="problema" name="problema" required>
                <option selected disabled value="">Escolha...</option>
                <option value="1">Internet</option>
                <option value="2">Telefone</option>
                <option value="3">Computador</option>
                <option value="4">Impressora</option>
                <option value="5">SEI</option>
                <option value="6">Outro...</option>
              </select>
            </div>
            <div class="col-12">
              <div class="form-floating">
                <div class="text-cadastro mt-1">Descreva o problema:</div>
                <textarea name="outros" class="form-control form-cad my-3" id="descricao" style="height: 120px" maxlength="420"></textarea>
              </div>
            </div>
            <div class="col-12 mb-md-0 mb-5">
              <div class="row">
                  <button class="btn btn-cad" type="submit">Enviar</button> 
                  <button class="btn btn-cad" type="reset">Limpar Campos</button>
                  <button type="button" value="Voltar" onClick="history.go(-1)" class="btn btn-cad" type="">Voltar</button>
              </div>
            </div>
          </form>
          <div class="row">
            <div class="col-12 mb-md-0 mb-5 mt-5">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Scrips JS Boostrap -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="./script.js"></script>
<script src="../Assets/js/script.js"></script>
<script src="../Assets/js/table.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</body>

</html>