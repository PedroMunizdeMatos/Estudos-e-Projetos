<?php include("../Model/model_MostraCompleto.php"); ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metatags Obrigatórias -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <!-- CSS -->
    <link href="../Assets/css/mostraChamadoBegins.css" rel="stylesheet">
    <link href="../Assets/css/font.css" rel="stylesheet">
    <title>Chamado nº <?php echo $id_chamado; ?></title>
    <link rel="icon" href="../Assets/img/icone.png">
</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-light bg-light" role="navigation">
        <a class="navbar-brand" href="index.php">
            <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65" style="margin-left: 30px;">
        </a>
        <div class="navbar-header">
            <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%" style="margin-left: -30px;" class="d-inline-block align-text-center">
        </div>

        <div class="collapse navbar-collapse">
        </div>
    </nav>
    <!-- fim navbar -->

    <div class="row">
        <div class="col-3 col-sm col-md col-lg-5 margin-h1">
        </div>
        <div class="col-6 col-sm col-md col-lg-4 margin-h1">
            <div class="type-js headline">
                <a href="mostraChamadoCliente.php" style="text-decoration: none;"><h1 class="text-js h1-chamado">Meus Chamados</h1></a>
            </div>
        </div>
        <div class="col-3 col-sm col-md col-lg-3 margin-h1">
        </div>
        <div class="linha-deco">
        </div>
    </div>

    <!-- Chamado completo - Cliente -->
    <div class="container">
        <div class="row">
            <div class="countainer-chamado">
                <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-5 mt-3">
                    <h1>Nº do Chamado: <?php echo $id_chamado ?></h1>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-5 mt-5">
                        <h4><strong>Solicitante:</strong></h4>
                        <?php echo $nome ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-5 mt-2">
                        <h4><strong>Problema:</strong></h4> <?php 
                        if($vr_problema == 1){
                            echo "Internet";
                        }
                        if($vr_problema == 2){
                            echo "Telefone";
                        }
                        if($vr_problema == 3){
                            echo "Computador";
                        }
                        if($vr_problema == 4){
                            echo "Impressora";
                        }
                        if($vr_problema == 5){
                            echo "SEI";
                        }
                        if($vr_problema == 6){
                            echo "Outro";
                        } ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-5 mt-2">
                        <h4><strong>Departamento:</strong></h4><?php echo $depto ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-4 mt-2">
                        <h4><strong>Data e hora de Abertura:</strong></h4> <?php echo $data ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-4 mt-2">
                        <h4><strong>Status atual do Chamado:</strong></h4> <?php
                        if ($status == 1) {
                            echo "Aguardando Tecnico";
                          }
                          if ($status == 2) {
                            echo "Em andamento";
                          }
                          if ($status == 3) {
                            echo "Encerrado";
                          }
                         ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-0 mb-md-0 mb-0 mt-0">
                        <div class="card-body">
                            <h4 class="card-text"><strong>Relato</strong></h4><?php echo $vr_problema2?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Parte Técnico -->
    <div class="container">
        <div class="row">
            <div class="countainer-chamado countainer-tecnico">
                <div class="col-12 col-lg-12 col-md-12 align-self-center ms-3 mb-md-0 mb-5 mt-3">
                    <h1>Técnico Responsável</h1>
                    <!-- Nome do técnico aqui -->
                    <h3><?php echo $adm2 ?></h3>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-0 mb-md-0 mb-0 mt-0">
                
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12 col-md-12 align-self-center ms-0 mb-md-0 mb-0 mt-0">
                        <div class="card-body">
                            <!-- Comentario do Tecnico aqui -->
                            <h4 class="card-text"><strong>Observação:</strong></h4><?php echo $status2 ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- Scrips JS Boostrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>