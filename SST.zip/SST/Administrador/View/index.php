<?php 
      setcookie('matricula', null, -1, '/'); 
      session_start();
      session_destroy();
?>


<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Metatags Obrigatórias -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

  <!-- CSS -->
  <link href="../Assets/css/estilo.css" rel="stylesheet">
  <link href="../Assets/css/font.css" rel="stylesheet">


  <!-- Script Código html-->
  <script language="JavaScript">
    function protegercodigo() {
    if (event.button==2||event.button==3){
        alert('Para abrir um chamado clique em "Abrir um Chamado"...');}
    }
    document.onmousedown=protegercodigo

  </script>
  <title>Suporte Técnico TCB</title>
  <link rel="icon" href="../Assets/img/icone.png">

</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-light bg-light" role="navigation">
    <a class="navbar-brand" href="../View/index.php">
      <img src="../Assets/img/tcbbranco.png" alt="Logo da TCB branco" width="100" height="65"
        style="margin-left: 30px;">
    </a>
    <div class="navbar-header">
      <img src="../Assets/img/UTINF.png" alt="Logo da UTINF branco" width="100%" height="85%"
        style="margin-left: -30px;" class="d-inline-block align-text-center">
    </div>

    <div class="collapse navbar-collapse">
    </div>
  </nav>
  <!-- fim navbar -->

  <div class="container countainer-busca">
    <div class="row">
      <div class="col-lg-12">
        <h2>Busque seu chamado aqui</h2>
          <div class="row">
            <form method="POST" action="../Controller/controller_PaginaInicial.php" class="d-flex" style="padding-bottom: 120px; ">
              <input name="matricula" class="form-control me-2 formularios-index"  type="search" placeholder="Digite sua matrícula..." aria-label="BuscarMatricula" minlength="4" maxlength="8" />
                <button class="main-btn" type="submit">Buscar</button>
            </form>
        </div>
      </div>  
    </div>
  </div>
  <!-- carousel -->
  <div id="slider" class="block">
    <div class="container countainer-slider">
      <div class="row">
          <div class="col-12 col-lg-6 col-md-6 align-self-center mb-md-0 mb-4">
            <h1>Passando por algum problema técnico ?</h1>
            <h5>Abra um chamado e em breve iremos atendê-lo...</h5>
          <br>
          <br>
            <a
              href="cadastro.php"
              class="second-btn d-md-inline-block d-block mb-md-0 mb-2 mr-md-2"
              >Abrir Chamado</a>
          </div>
          <div class="col-12 col-lg-6 col-md-6 align-self-center text-center">
            <img src="../Assets/img/slider.png" class="img-fluid" />
          </div>
      </div>
    </div>
  </div>
  <div class="container pre-footer">
    <div class="row">
      <div class="col-lg-12"></div>
    </div>
  </div>
  <!-- Footer -->
  <footer class="bd-footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <a href="../Administrador/View/login.php">
            <img src="../Assets/img/UTINF.png" width="150">
          </a>
        </div>
        
        <div class="col-lg-12">
          <div class="footer-copyright text-center py-3">PY © 2021 TCB UTINF
          </div>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scrips JS Boostrap -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
    integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
    integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
    crossorigin="anonymous"></script>
</body>

</html>