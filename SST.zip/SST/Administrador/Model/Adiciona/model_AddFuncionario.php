<?php
include_once ("../../../Model/DB_connection.php");

session_start();

$nome = $_COOKIE['add_nome_usuario'];
$matricula = $_COOKIE['add_matricula_usuario'];

$sql_code = "INSERT INTO pessoa (Matrícula, Nome) VALUES ($matricula, $nome)";

$resultado = mysqli_query($conexao, $sql_code) or die("<script>
                                                     alert('Erro ao cadastrar Pessoa, código (model_AddFuncionario)');
                                                     location.href='../../View/ademiro.php';
                                                     </script>");
if (!$resultado)
{
    echo "<script>
    alert('Erro ao cadastrar funcionario, código (model_AddFuncionario)');
    location.href='../../View/ademiro.php';
    </script>";
    setcookie('add_nome_usuario', null, -1, '/'); 
    setcookie('add_matricula_usuario', null, -1, '/'); 
}
else
{
    echo "
    <script>
     alert('Inserido com sucesso');
     location.href='../../View/cadastroPessoa.php';
    </script>";
    setcookie('add_nome_usuario', null, -1, '/'); 
    setcookie('add_matricula_usuario', null, -1, '/'); 
}

?>