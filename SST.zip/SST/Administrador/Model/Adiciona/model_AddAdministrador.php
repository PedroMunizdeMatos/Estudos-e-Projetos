<?php
include_once ("../../../Model/DB_connection.php");

session_start();

$nome = $_SESSION['nome'];
$matricula = $_SESSION['matricula'];
$senha = $_SESSION['senha'];
$nivel = $_SESSION['nivel'];

$sql_code = "INSERT INTO administrador (matricula, senha, nome, nivel) VALUES ($matricula, sha1($senha), $nome, $nivel)";
$resultado = mysqli_query($conexao, $sql_code) or die("<script>
                                                     alert('Erro ao cadastrar Administrador, código (model_AddAdministrador)');
                                                     location.href='../../View/ademiro.php';
                                                     </script>");
if (!$resultado)
{
    echo "<script>
    alert('Erro ao cadastrar Administrador, código (model_AddAdministrador)');
    location.href='../../View/ademiro.php';
    </script>";
    session_destroy();
}

else
{
    echo "
    <script>
     alert('Inserido com sucesso');
     location.href='../../View/cadastroAdministrador.php';
    </script>";
    session_destroy();
}

?>
