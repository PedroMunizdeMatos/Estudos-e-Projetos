<?php
include_once ("../../../Model/DB_connection.php");
session_start();

$nome = $_SESSION['nome'];
$matricula = $_SESSION['matricula'];
$senha = $_SESSION['senha'];
$idMatricula = $_SESSION['idMatricula'];
$nivel = $_SESSION['nivel'];

$sql_code = "UPDATE administrador SET matricula = $matricula, senha = SHA1($senha), nome = $nome WHERE matricula = $idMatricula";
//$sql_code = "UPDATE administrador SET matricula = $matricula, nome = $nome, nivel = $nivel WHERE matricula = $idMatricula";
$resultado = mysqli_query($conexao,$sql_code) or die("<script>
alert('Erro código (model_EditAdministrador) 01');
location.href='../../View/administrador.php';
</script>");

if(mysqli_affected_rows($conexao) > 0){
    session_destroy();
    echo"
    <script>
     alert('Editado com sucesso');
     location.href='../../View/administrador.php';
    </script>";
    
}else{
    session_destroy();
    echo"
    <script>
     alert('Não foi possível editar no Banco de Dados');
     location.href='../../View/administrador.php';
    </script>";
    
}

?>