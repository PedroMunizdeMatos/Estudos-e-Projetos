<?php
include_once ("../../../Model/DB_connection.php");

$idChamado = $_COOKIE['idChamado']; 
$nome = $_COOKIE['nome'];
$matricula = $_COOKIE['matricula']; 
$departamento = $_COOKIE['departamento'];
$n_problema = $_COOKIE['n_problema'];

$departamento2 = $_COOKIE['departamento2_editC2'];


if ($n_problema == 'Internet'){
    $n_problema = 1;
}
if ($n_problema == 'Telefone'){
    $n_problema = 2;
}
if ($n_problema == 'Computador'){
    $n_problema = 3;
}
if ($n_problema == 'Impressora'){
    $n_problema = 4;
}
if ($n_problema == 'SEI'){
    $n_problema = 5;
}
if ($n_problema == 'Outro...'){
    $n_problema = 6;
}

$ramal = $_COOKIE['ramal'];
$descricao_problema = $_COOKIE['descricao_problema'];
$status = $_COOKIE['status'];


$observacao_tecnico = $_COOKIE['observacao_tecnico'];
$matr_administrador = $_COOKIE['admin']; //vou pegar uma nova matricula
$data = $_COOKIE['data_editC2'];
$var = 0;
 $nome;  
 $matricula;  
 $departamento;  
 $descricao_problema ;  
 $status;  
 $observacao_tecnico  ;  
 $data ; 
 $ramal;  


//-----------------------------------------------------------------------------------------------------------
//Busca o id do Chamado para armazenar em variaveis

$sql_code = "SELECT * FROM chamado WHERE idChamado = $idChamado";
$resultado = mysqli_query($conexao, $sql_code) or die("
     <script>
     alert('Não foi possível selecionar este id do Chamado (Model_EditChamado error');
     location.href='../View/editChamado.php';
    </script>");

$result = mysqli_num_rows($resultado);

if ($result > 0){
    $registro = mysqli_fetch_array($resultado);
    $BD_problema = $registro['Fk_Problema'];
    $BD_departamento = $registro['Fk_Departamento'];
    $BD_pessoa = $registro['Pessoa'];
    $BD_tecnico = $registro['Fk_Tecnico'];
    $BD_adm = $registro['Administrador'];
    $BD_data = $registro['Data_chamado'];
}
else{

    echo "<script>
          alert('Erro ao buscar id do Chamado');
          location.href='../../View/editChamado.php';
          </script>";

}

    $BD_problema = "'".$BD_problema."'";
    $BD_tecnico = "'".$BD_tecnico."'";

//-----------------------------------------------------------------------------------------------------------
//MATRICULA PESSOA

$sql_pessoa = "SELECT * FROM pessoa WHERE Matrícula = $matricula";
$result_pessoa = mysqli_query($conexao, $sql_pessoa) or die("Erro de checagem (model_EditChamado) 00 ");
$resultado_pessoa = mysqli_num_rows($result_pessoa);

if ($resultado_pessoa > 0)
{
    $var = $var + 1;
}
else
{

    echo "<script>
          alert('Matrícula da Pessoa não existe no Banco de Dados');
          location.href='../../View/editChamado.php';
          </script>";

}

//-----------------------------------------------------------------------------------------------------------
//ADMINISTRADOR

$sql_administrador = "SELECT * FROM administrador WHERE matricula = $matr_administrador";
$result_administrador = mysqli_query($conexao, $sql_administrador) or die("Erro de checagem (model_EditChamado) 01 ");
$resultado_administrador = mysqli_num_rows($result_administrador);

if ($resultado_administrador > 0)
{
    $var = $var + 1;
}
else
{

    echo "<script>
          alert('Matrícula de Administrador não existe no Banco de Dados');
          location.href='../../View/editChamado.php';
          </script>";

}

//-----------------------------------------------------------------------------------------------------------
//PROBLEMA E DESCRICAO DO PROBLEMA


$sql_select_problema = "SELECT * FROM problema WHERE idProblema = $BD_problema"; 
$resultado_select_problema = mysqli_query($conexao, $sql_select_problema) or die("Erro de checagem (model_EditChamado) 02");
$result_select_problema = mysqli_num_rows($resultado_select_problema);

if ($result_select_problema > 0){

    $var = $var + 1;

}
else
{
    echo "<script>
          alert('Problema não armazenado no banco');
          location.href='../../View/editChamado.php';
          </script>";
}

//-----------------------------------------------------------------------------------------------------------

//DEPARTAMENTO

$sql_select_departamento = "SELECT * FROM departamento WHERE idDepartamento = $departamento"; 
$resultado_select_departamento = mysqli_query($conexao, $sql_select_departamento) or die("Erro de checagem (model_EditChamado) 03");
$result_select_departamento = mysqli_num_rows($resultado_select_departamento);

if ($result_select_departamento > 0){

    $var = $var + 1;

}
else
{
    echo "<script>
          alert('Departamento não existente no Banco de Dados');
          location.href='../../View/editChamado.php';
          </script>";
}

//-----------------------------------------------------------------------------------------------------------
//TECNICO - STATUS E OBSERVACAO

$sql_select_tecnico = "SELECT * FROM tecnico WHERE idTecnico = $BD_tecnico"; 
$resultado_select_tecnico = mysqli_query($conexao, $sql_select_tecnico) or die("Erro de checagem (model_EditChamado) 04");
$result_select_tecnico = mysqli_num_rows($resultado_select_tecnico);

if ($result_select_tecnico > 0){

    $var = $var + 1;

}
else
{
    echo "<script>
          alert('status ou observação de tecnico não existente no Banco de Dados');
          location.href='../../View/editChamado.php';
          </script>";
}


//-----------------------------------------------------------------------------------------------------------



if($var == 5){

    //PESSOA
    $sql_matr_pessoa = "UPDATE chamado SET Pessoa = $matricula WHERE idChamado = $idChamado";
    $result_matr_pessoa = mysqli_query($conexao, $sql_matr_pessoa) or die("Erro código (model_EditChamado) 00 ");

    //tabela chamado Administrador
    $sql_matr_administrador = "UPDATE chamado SET Administrador = $matr_administrador WHERE idChamado = $idChamado";
    $result_matr_administrador = mysqli_query($conexao, $sql_matr_administrador) or die("Erro código (model_EditChamado) 01 ");
    
    //PROBLEMA E DESCRICAO DO PROBLEMA
    $sql_update_problema = "UPDATE problema SET Problema = $n_problema WHERE idProblema = $BD_problema";
    $result_update_problema = mysqli_query($conexao, $sql_update_problema) or die("Erro código (model_EditChamado) 02 ");

    $sql_desc_update_problema = "UPDATE problema SET Descricao = $descricao_problema WHERE idProblema = $BD_problema";
    $result_desc_update_problema = mysqli_query($conexao, $sql_desc_update_problema) or die("Erro código (model_EditChamado) 03 ");

    //DEPARTAMENTO
    $sql_chamado_departamento = "UPDATE chamado SET Fk_Departamento = $departamento WHERE idChamado = $idChamado";
    $result_chamado_departamento = mysqli_query($conexao, $sql_chamado_departamento) or die("Erro código (model_EditChamado) 04 ");

    //TECNICO E OBSERVAÇÃO DO TECNICO
    $sql_update_tecnico = "UPDATE tecnico SET `status` = $status WHERE idTecnico = $BD_tecnico";
    $result_update_tecnico = mysqli_query($conexao, $sql_update_tecnico) or die("Erro código (model_EditChamado) 05 ");

    $sql_update_desc_tecnico = "UPDATE tecnico SET observacao = $observacao_tecnico WHERE idTecnico = $BD_tecnico";
    $result_update_desc_tecnico = mysqli_query($conexao, $sql_update_desc_tecnico) or die("Erro código (model_EditChamado) 06 ");

    //DATA  
    $sql_ramal = "UPDATE pessoa SET Ramal = $ramal WHERE Matrícula = $matricula";
    $result_ramal = mysqli_query($conexao, $sql_ramal) or die("Erro código (model_EditChamado) 08 ");

    //RAMAL
    
    

$var = 10;
}

if ($var = 10)
{

    //controllerEditPessoa
    setcookie('idChamado', null, -1, '/');
    setcookie('nome', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('departamento', null, -1, '/');
    setcookie('n_problema', null, -1, '/');
    setcookie('descricao_problema', null, -1, '/');
    setcookie('status', null, -1, '/');
    setcookie('observacao_tecnico', null, -1, '/');
    setcookie('matr_administrador', null, -1, '/');
    setcookie('data', null, -1, '/');
    

    echo "
    <script>
     alert('Editado com sucesso');
     location.href='../../View/ademiro.php';
    </script>";

}
else
{
    setcookie('idChamado', null, -1, '/');
    setcookie('nome', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('departamento', null, -1, '/');
    setcookie('n_problema', null, -1, '/');
    setcookie('descricao_problema', null, -1, '/');
    setcookie('status', null, -1, '/');
    setcookie('observacao_tecnico', null, -1, '/');
    setcookie('matr_administrador', null, -1, '/');
    setcookie('data', null, -1, '/');

    echo "
    <script>
     alert('Não foi possível editar no Banco de Dados');
     location.href='../../View/ademiro.php';
    </script>";
}


?>
