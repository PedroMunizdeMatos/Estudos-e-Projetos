<?php
include_once ("../../../Model/DB_connection.php");

$idMatricula = $_COOKIE['idMatricula'];

$sql_code = "SELECT * FROM pessoa WHERE Matrícula = $idMatricula";
$resultado = mysqli_query($conexao, $sql_code) or die("
     <script>
     alert('Matrícula inválida');
     location.href='../View/editPessoa.php';
    </script>");

$result = mysqli_num_rows($resultado);

if ($result > 0)
{
 
    $registro = mysqli_fetch_array($resultado);
    $pega_nome = $registro['Nome'];
    $pega_matricula = $registro['Matrícula'];
    $pega_ramal = $registro['Ramal'];

    //$pega_nome = str_replace('"', '``', str_replace("'", "", $pessoa));

    setcookie('nome_pessoa', $pega_nome, time() + 3600, '/');
    setcookie('matricula', $pega_matricula, time() + 3600, '/');
    setcookie('ramal', $pega_ramal, time() + 3600, '/');

    echo "<script>
         location.href='../../View/editPessoa.php';
         </script>";


}
else
{
    echo "<script>
        alert('Não foi possível encontrar resultados com esta matrícula, contate o suporte');
        location.href='../View/ademiro.php';
       </script>";
}

?>
