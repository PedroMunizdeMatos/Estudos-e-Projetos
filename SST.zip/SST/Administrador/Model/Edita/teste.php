<?php
include_once ("../../../Model/DB_connection.php");

$sql_data = "UPDATE chamado SET Fk_Departamento = 9 WHERE idChamado = 1";
$result_data = mysqli_query($conexao, $sql_data);

if(mysqli_affected_rows($conexao) >= 0){    
  echo mysqli_affected_rows($conexao);
}else {
    echo mysqli_affected_rows($conexao);
}

?>