<?php

include_once ("../../../Model/DB_connection.php");

    session_start();

    $idMatricula = $_SESSION['idMatricula'];

    $sql_code = "SELECT * FROM administrador WHERE matricula = $idMatricula";
    $resultado = mysqli_query($conexao,$sql_code) or die("
     <script>
     alert('Matrícula inválida');
     location.href='../View/editPessoa.php';
    </script>"
    );

    $result = mysqli_num_rows($resultado);

    if($result > 0){
    $registro = mysqli_fetch_array($resultado);

    $pega_nome = $registro['nome'];
    $pega_matricula = $registro['matricula'];

    $_SESSION['nome_administrador'] = $pega_nome;
    $_SESSION['matricula_administrador'] = $pega_matricula;

    echo "<script>
         location.href='../../View/editAdministrador.php';
         </script>";
    
    }else{
        echo "<script>
        alert('Não foi possível encontrar resultados com esta matrícula');
        location.href='../../View/editAdministrador.php';
       </script>";
    }


    
?>