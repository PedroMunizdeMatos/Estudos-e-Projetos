<?php
include_once ("../../../Model/DB_connection.php");

$idChamado = $_COOKIE['idChamado'];

$sql_code = "SELECT * FROM chamado WHERE idChamado = $idChamado";
$resultado = mysqli_query($conexao, $sql_code) or die("
     <script>
     alert('Não foi possível selecionar este id do Chamado');
     location.href='../View/editChamado.php';
    </script>");

$result = mysqli_num_rows($resultado);

if ($result > 0)
{
    $registro = mysqli_fetch_array($resultado);
    $problema = $registro['Fk_Problema'];
    $departamento = $registro['Fk_Departamento'];
    $pessoa = $registro['Pessoa'];
    $tecnico = $registro['Fk_Tecnico'];
    $adm = $registro['Administrador'];
    $data = $registro['Data_chamado'];
    
        //Puxa o nome da pessoa na qual tem aquele tipo de matrícula
        $pessoa = "'".$pessoa."'";
        $sql_nome = "SELECT Nome FROM pessoa WHERE Matrícula = $pessoa"; 
        $result_nome = mysqli_query($conexao,$sql_nome) or die("Erro ao puxar nome do colaborador");

                //variavel do nome do colaborador
                $var_nome = mysqli_fetch_array($result_nome);
                $nome = $var_nome['Nome'];
        
        //Departamento
        $sql_departamento = "SELECT nome_departamento FROM departamento WHERE idDepartamento = $departamento"; 
        $result_departamento = mysqli_query($conexao,$sql_departamento) or die("Erro ao puxar status");

                $var_depto = mysqli_fetch_array($result_departamento);
                $depto = $var_depto['nome_departamento'];
        
        //ver ramal---------------------------------------------------------------
            $sql_ramal = "SELECT Ramal FROM pessoa WHERE Matrícula = $pessoa"; 
            $result_ramal = mysqli_query($conexao,$sql_ramal) or die("Erro ao puxar informação do ramal");
    
                    $var_ramal =  mysqli_fetch_array($result_ramal);
                    $vr_ramal = $var_ramal['Ramal'];

                    if($vr_ramal == NULL){
                        $vr_ramal = 9999;
                    }


        //Problema - numero dele
        $sql_problema = "SELECT Problema FROM problema WHERE idProblema = $problema"; 
        $result_problema = mysqli_query($conexao,$sql_problema) or die("Erro ao puxar informação do problema");

                $var_problema =  mysqli_fetch_array($result_problema);
                $vr_problema = $var_problema['Problema'];

        //descricao do problema  - descrição
        $sql_problema2 = "SELECT Descricao FROM problema WHERE idProblema = $problema"; 
        $result_problema2 = mysqli_query($conexao,$sql_problema2) or die("Erro ao puxar descricao do problema");

                $var_problema2 =  mysqli_fetch_array($result_problema2);
                $vr_problema2 = $var_problema2['Descricao'];

                if($vr_problema2 == null){
                        $vr_problema2 = 'Sem relato';
                }

        //status do chamado
        $sql_status = "SELECT `status` FROM tecnico WHERE idTecnico = $tecnico"; 
        $result_status = mysqli_query($conexao,$sql_status) or die("Erro ao puxar status");

                //variavel para puxar o status
                $var_status =  mysqli_fetch_array($result_status);
                $status = $var_status['status'];

        
        //observação do tecnico
        $sql_status2 = "SELECT observacao FROM tecnico WHERE idTecnico = $tecnico"; 
        $result_status2 = mysqli_query($conexao,$sql_status2) or die("Erro ao puxar status");

                //variavel para puxar o status
                $var_status2 =  mysqli_fetch_array($result_status2);
                $status2 = $var_status2['observacao'];

                $pessoa = str_replace('"', '``', str_replace("'", "", $pessoa));

                     if($vr_problema == 1){
                        setcookie('n_problema_editC2', "Internet", time() + 3600, '/');                    }
                    if($vr_problema == 2){
                        setcookie('n_problema_editC2', "Telefone", time() + 3600, '/');                    }
                    if($vr_problema == 3){
                        setcookie('n_problema_editC2', "Computador", time() + 3600, '/');                    }
                    if($vr_problema == 4){
                        setcookie('n_problema_editC2', "Impressora", time() + 3600, '/');                    }
                    if($vr_problema == 5){
                        setcookie('n_problema_editC2', "SEI", time() + 3600, '/');                    }
                    if($vr_problema == 6){
                        setcookie('n_problema_editC2', "Outro", time() + 3600, '/');                    } 

                setcookie('nome_editC2', $nome, time() + 3600, '/');
                setcookie('matricula_editC2', $pessoa, time() + 3600, '/');
                setcookie('departamento_editC2', $depto, time() + 3600, '/');
                setcookie('departamento2_editC2', $departamento, time() + 3600, '/');
                setcookie('descricao_problema_editC2', $vr_problema2, time() + 3600, '/');
                setcookie('status_editC2', $status, time() + 3600, '/');
                setcookie('observacao_tecnico_editC2', $status2, time() + 3600, '/');
                setcookie('matr_administrador_editC2', $adm, time() + 3600, '/');
                setcookie('data_editC2', $data, time() + 3600, '/');
                setcookie('ramal_editC2', $vr_ramal, time() + 3600, '/');


    echo "<script>
         location.href='../../View/editChamado.php';
         </script>";
}
else
{
    echo "<script>
        alert('Não foi possível encontrar resultados com este iD, contate o suporte');
        location.href='../../View/ademiro.php';
       </script>";
}

?>
