<?php
include_once ("../../../Model/DB_connection.php");

$ramal = $_COOKIE['ramal'];
$nome = $_COOKIE['nome'];
$matricula = $_COOKIE['matricula'];
$idMatricula = $_COOKIE['idMatricula'];

$sql_code = "UPDATE pessoa SET Matrícula = $matricula, Nome = $nome, Ramal = $ramal WHERE Matrícula = $idMatricula";

//$sql_code = "UPDATE pessoa SET Matrícula = $matricula, Nome = $nome WHERE Matrícula = $idMatricula";

$resultado = mysqli_query($conexao, $sql_code) or die("Erro código (model_EditPessoa) 01 ");

if(mysqli_affected_rows($conexao) > 0){

    $sql_code = "SELECT * FROM chamado WHERE Pessoa = $idMatricula";
    $resultado2 = mysqli_query($conexao, $sql_code) or die("
     <script>
     alert('Matrícula inválida 001');
     location.href='../View/editPessoa.php';
    </script>");

    while($registro = mysqli_fetch_array($resultado2))
            {
                //armazena a cada loop um registro do banco nas variáveis e as mostra na tela com o echo
                $id_chamado = $registro['idChamado'];
                $problema = $registro['Fk_Problema'];
                $departamento = $registro['Fk_Departamento'];
                $pessoa = $registro['Pessoa'];
                $tecnico = $registro['Fk_Tecnico'];
                $adm = $registro['Administrador'];
                $data = $registro['Data_chamado'];

        $sql_code = "UPDATE chamado SET Pessoa = $matricula WHERE Pessoa = $idMatricula";
        $resultado = mysqli_query($conexao, $sql_code) or die(" <script>
        alert('Erro código (model_EditPessoa) 011');
        location.href='../View/editPessoa.php';
         </script>");    
            }

    //controllerEditPessoa
    setcookie('nome', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('ramal', null, -1, '/');

    //controllerEditPessoa2
    setcookie('idMatricula', null, -1, '/');

    //modelEditPessoa2
    setcookie('nome_pessoa', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('ramal', null, -1, '/');

    //quando editar uma pessoa, fazer ela ser editada automaticamente no chamado
    //quando editar matricula ou nome no chamado, tem que editar nas tabelas em si também 
    //
    //$sql_code = "UPDATE chamado SET Pessoa = $matricula WHERE idChamado = $idChamado";
    //$resultado = mysqli_query($conexao, $sql_code) or die("Erro código (model_EditPessoa) 01 //");
    
    echo "
    <script>
     alert('Editado com sucesso');
     location.href='../../View/pessoa.php';
    </script>";


}
else
{

    //controllerEditPessoa
    setcookie('nome', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('ramal', null, -1, '/');

    //controllerEditPessoa2
    setcookie('idMatricula', null, -1, '/');

    //modelEditPessoa2
    setcookie('nome_pessoa', null, -1, '/');
    setcookie('matricula', null, -1, '/');
    setcookie('ramal', null, -1, '/');

    echo "
    <script>
     alert('Não foi feita nenhuma edição no Banco de Dados');
     location.href='../../View/pessoa.php';
    </script>";
    
}

?>
