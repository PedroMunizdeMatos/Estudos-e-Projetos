<?php 

include("../../../Model/DB_connection.php");

        $sql_code = "SELECT * FROM chamado where Pessoa = '2958' order by idChamado DESC"; 
        $resultado_chamado = mysqli_query($conexao,$sql_code) or die("Erro código (model_chamadosBusca)");

while($registro = mysqli_fetch_array($resultado_chamado))
    {
        $id_chamado = $registro['idChamado'];
        $problema = $registro['Fk_Problema'];
        $departamento = $registro['Fk_Departamento'];
        $pessoa = $registro['Pessoa'];
        $tecnico = $registro['Fk_Tecnico'];
        $adm = $registro['Administrador'];
        $data = $registro['Data_chamado'];

        //Puxa o nome da pessoa na qual tem aquele tipo de matrícula
        $pessoa = "'".$pessoa."'";
        $sql_nome = "SELECT Nome FROM pessoa WHERE Matrícula = $pessoa"; 
        $result_nome = mysqli_query($conexao,$sql_nome) or die("Erro ao puxar nome do colaborador");

                //variavel do nome do colaborador
                $var_nome = mysqli_fetch_array($result_nome);
                $nome = $var_nome['Nome'];

        
        //Departamento
        $sql_departamento = "SELECT nome_departamento FROM departamento WHERE idDepartamento = $departamento"; 
        $result_departamento = mysqli_query($conexao,$sql_departamento) or die("Erro ao puxar status");

                $var_depto = mysqli_fetch_array($result_departamento);
                $depto = $var_depto['nome_departamento'];


        //Problema
        $sql_problema = "SELECT Problema FROM problema WHERE idProblema = $problema"; 
        $result_problema = mysqli_query($conexao,$sql_problema) or die("Erro ao puxar informação do problema");

                $var_problema =  mysqli_fetch_array($result_problema);
                $vr_problema = $var_problema['Problema'];

        //status do chamado
        $sql_status = "SELECT `status` FROM tecnico WHERE idTecnico = $tecnico"; 
        $result_status = mysqli_query($conexao,$sql_status) or die("Erro ao puxar status");

                //variavel para puxar o status
                $var_status =  mysqli_fetch_array($result_status);
                $status = $var_status['status'];              
    
        echo "<br>";
        echo "<br>";
       echo $id_chamado;
       echo $nome; 
       echo $depto; 
       echo $vr_problema; 
       echo $status; 
       echo "<br>";
       echo "<br>";
    }
?>