<?php

include("../../Model/DB_connection.php");


      /* $sinal = 2;
       $info = '4';
       $info = "'".$info."'";
       setcookie('sinal', $sinal, time()+10, '/');
       setcookie('informacao', $info, time()+10, '/');
               */
      $valor = isset($_COOKIE['sinal']) ? 'S' : 'N';

        if($valor == 'S'){          

              //funcional //matrícula
          if($_COOKIE['sinal'] == 1){
                 $informacao = $_COOKIE['informacao'];
                 $sql_code = "SELECT * FROM chamado where Pessoa LIKE $informacao order by idChamado DESC"; 
                }
                
              //funcional //departamento
          if($_COOKIE['sinal'] == 2){
                 $informacao = $_COOKIE['informacao'];
                 $sql_code = "SELECT * FROM chamado where Fk_Departamento = $informacao order by idChamado DESC";
                }

            //funcional //idchamado
          if($_COOKIE['sinal'] == 3){
                  $informacao = $_COOKIE['informacao'];
                  $sql_code = "SELECT * FROM chamado where idChamado = $informacao order by idChamado DESC"; 
                 }
            
              //funcional //data
          if($_COOKIE['sinal'] == 4){
            $informacao = $_COOKIE['informacao'];
            $sql_code = "SELECT * FROM chamado WHERE Data_chamado LIKE $informacao order by idChamado DESC"; 
           }
            

          if($_COOKIE['sinal'] != 1 && $_COOKIE['sinal'] != 2 && $_COOKIE['sinal'] != 3 && $_COOKIE['sinal'] != 4 ){
              $sql_code = "SELECT * FROM chamado order by idChamado DESC";   
          }

        }
        else{
              $sql_code = "SELECT * FROM chamado order by idChamado DESC";    
        }
        
        $resultado_chamado = mysqli_query($conexao,$sql_code) or die("Erro código (model_chamadosTotais)");
    
?>
