<?php

include("../../Model/DB_connection.php");

        $sql_code = "SELECT * FROM administrador"; 
        $resultado_chamado = mysqli_query($conexao,$sql_code) or die("Erro código (model_M_administrador)");
        
?>