<?php

include("../../Model/DB_connection.php");

       /* como deve ser criado os filtros?
        inicialmente a página deve vir com o filtro 0 setada
        ao colocar um filtro receberei 2 informações:
        o número do filtro + uma informação do filtro
        ela irá à controller e depois retornará diretamente para a view, a model terá que ler automaticamente
        verificar o include na view caso ele não atualize
        e então o valor da controller fica por exemplo 1
        será um cookie como uma variável global
        terá que ter um campo para zerar o filtro para setar o valor dnv a 0

       */
  
       //pagina mostra administradores
               
      $valor = isset($_COOKIE['sinal']) ? 'S' : 'N';

        if($valor == 'S'){

          if($_COOKIE['sinal'] == 1){
                 $informacao = $_COOKIE['informacao'];
                 $sql_code = "SELECT * FROM pessoa where Matrícula = $informacao"; 
         
                }
         
          if($_COOKIE['sinal'] == 2){
                 $informacao = $_COOKIE['informacao'];
                 $sql_code = "SELECT * FROM pessoa where Nome LIKE $informacao";
                }
         
          if($_COOKIE['sinal'] == 3){
                 $informacao = $_COOKIE['informacao'];
                 $sql_code = "SELECT * FROM pessoa where Ramal = $informacao";     
                }

          if($_COOKIE['sinal'] != 1 && $_COOKIE['sinal'] != 2 && $_COOKIE['sinal'] != 3 ){
                $sql_code = "SELECT * FROM pessoa";  
        
          }

        }
        else{
                $sql_code = "SELECT * FROM pessoa ORDER BY Nome";  
        }
        
        $resultado_chamado = mysqli_query($conexao,$sql_code) or die("Erro código (model_M_pessoa)");
    
?>
