<?php
include_once ("../../../Model/DB_connection.php");

session_start();

$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];

//com criptografia
$sql_code = "SELECT * FROM administrador WHERE matricula = $usuario && senha = SHA1($senha)";
$resultado = mysqli_query($conexao, $sql_code) or die("
     <script>
     alert('Verifique seu Usuário ou Senha');
     location.href='../../View/login.php';
    </script>");

$result = mysqli_num_rows($resultado);

if ($result > 0)
{
    $registro = mysqli_fetch_array($resultado);
    $pega_nome = $registro['nome'];
    $pega_matricula = $registro['matricula'];
    setcookie('user_logado', $pega_nome, time() + 3600, '/');
    setcookie('user_logado2', $pega_matricula, time() + 3600, '/');

    echo "
         <script>
         location.href='../../View/ademiro.php';
        </script>";
    exit();

}else{
    echo "
        <script>
         alert('Login ou Senha inválidos');
         location.href='../../View/login.php';
        </script>";
    exit();
}

?>
