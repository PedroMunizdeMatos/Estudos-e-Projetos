<?php
include_once ("../../../Model/DB_connection.php");


$matricula = $_COOKIE['del_Administrador'];

$sql_code = "DELETE FROM administrador WHERE matricula = $matricula";

$resultado = mysqli_query($conexao,$sql_code) or die("Erro código (model_DelAdministrador) 01 ");

$result = mysqli_affected_rows($conexao);

if($result > 0){
    echo"
    <script>
     alert('Excluído com sucesso');
     location.href='../../View/administrador.php';
    </script>";
}else{
    echo"
    <script>
     alert('Não foi possível excluir do Banco de Dados');
     location.href='../../View/administrador.php';
    </script>";
}

?>