<?php
include_once ("../../../Model/DB_connection.php");

session_start();

$matricula = $_COOKIE['del_funcionario'];

$sql_code = "DELETE FROM pessoa WHERE Matrícula = $matricula";

$resultado = mysqli_query($conexao,$sql_code) or die("Erro código (model_DelFuncionario) 01 ");

$result = mysqli_affected_rows($conexao);

if($result > 0){
    echo"
    <script>
     alert('Excluído com sucesso');
     location.href='../../View/ademiro.php';
    </script>";
}else{
    echo"
    <script>
     alert('Não foi possível excluir do Banco de Dados');
     location.href='../../View/ademiro.php';
    </script>";
}

?>